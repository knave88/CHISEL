function out = feat_ar (img)

warning('off','MATLAB:singularMatrix')
warning('off','MATLAB:nearlySingularMatrix')

%calculate parameters in img
[theta,sigma] = calculateTheta5 (img);
%[theta,sigma] = calculateTheta6 (img);

out.theta1 = no_nan(theta(1));
out.theta2 = no_nan(theta(2));
out.theta3 = no_nan(theta(3));
out.theta4 = no_nan(theta(4));

out.sigma = no_nan(sigma);



function out = no_nan (in)
if isnan(in)
    out = 0;
else
    out = in;
end
% end no_nan



% -------------------------------------------------------------------------
    function ws = createWs (s , img)
    %creates vector ws of image 'img' at desired point 's'
    %example:
    %s=[3 3]
    %img - read file with imread

    %get height and width of an image
    [h1,w1]=size(img);

    %get coordinates of neighbourhood of 's'
    Ns_coor={   [s(1)-1,s(2)-1],    [s(1)-1,s(2)],  [s(1)-1,s(2)+1];
                [s(1),s(2)-1],      s,              [s(1),s(2)+1];
                [s(1)+1,s(2)-1],    [s(1)+1,s(2)],  [s(1)+1,s(2)+1]};
    
    %for every point in neighbourhood of 's'
    for i=1:9
        %if it's on border of image fun returns NaN as a flag for main fun
        if Ns_coor{i}(1)<=0 || Ns_coor{i}(2)<=0 || Ns_coor{i}(1)>=h1 || Ns_coor{i}(2)>=w1
            ws=NaN;
            return;
        end
    end

    %if its outside the mask fun returns NaN as a flag for main fun
    if img(Ns_coor{1}(1),Ns_coor{1}(2))==0 || img(Ns_coor{2}(1),Ns_coor{2}(2))==0 ...
            || img(Ns_coor{4}(1),Ns_coor{4}(2))==0 || img(Ns_coor{7}(1),Ns_coor{7}(2))==0
        ws=NaN;
        return;
    end
    
    %continue if valid s
    
    %get values of points in neighbourhood of 's' needed for ws
    %Ns_out(1) = img(Ns_coor{1,2}(1),Ns_coor{1,2}(2));
    %Ns_out(2) = img(Ns_coor{1,1}(1),Ns_coor{1,1}(2));
    %Ns_out(3) = img(Ns_coor{2,1}(1),Ns_coor{2,1}(2));
    %Ns_out(4) = img(Ns_coor{3,1}(1),Ns_coor{3,1}(2));
    
    %create vector ws
    %ws=Ns_out';
    ws = [img(Ns_coor{1,2}(1),Ns_coor{1,2}(2)) ; img(Ns_coor{1,1}(1),Ns_coor{1,1}(2)) ; img(Ns_coor{2,1}(1),Ns_coor{2,1}(2)) ; img(Ns_coor{3,1}(1),Ns_coor{3,1}(2))];
    
    %end createWs


%--------------------------------------------------------------------------
function [theta,sigma] = calculateTheta5 (image)
% calculate parameter theta in a part of an image (argin)
%assumption: argin image is a segment from whole image where values outside
%segment are zeros
% not taking into account pixels that have any zero pixels in neighborhood
% by: lrosz

% -------------------------------------------------------------------------
%get height and width of an image
[h,w]=size(image);

%convert values to double
img=double(image);

%initialize variables needed to calculate parameter theta
factor1=0;
factor2=0;

%find points of mask in the image (uses indexing)
%(assumption: 'image' is a segment from whole image where values outside
%segment are zeros)
[masked_x, masked_y] = find(image);

%action taken for every nonzero point in the image
for points=1:length(masked_x)
    
    s(1) = masked_x(points);
    s(2) = masked_y(points);
        
    %call of the inside function 'createWs'
    ws = createWs (s , img);
    
    %if 'ws' is NaN it is border point and should not be taken into account
    if ~isnan(ws)
        %calculating theta
        tmp1=ws*ws';
        factor1=factor1+tmp1;
        tmp2=ws*img(s(1),s((2)));
        factor2=factor2+tmp2;
        
    end
    
end

%final theta calculation
theta=(((factor1)^(-1))*factor2);

%check if theta has 4 values if not first value is copied
%(need to return 'theta' as 1x4 matrix)
if numel(theta) ~= 4
    theta(2)=theta(1);
    theta(3)=theta(1);
    theta(4)=theta(1);
end

%calculate sigma parameter
%initialization of temporary variable
factor_sigma_sum=0;
%action taken for every nonzero point in the image
for points=1:length(masked_x)
    
    s(1) = masked_x(points);
    s(2) = masked_y(points);
    
    %call of the inside function 'createWs'
    ws = createWs (s , img);
    
    %if 'ws' is NaN it is border point and should not be taken into account
    if ~isnan(ws)
        %calculating sigma
        factor_sigma = (img(s(1),s(2)) - theta'*ws)^2;
        factor_sigma_sum=factor_sigma_sum+factor_sigma;
    end
    
end

%final sigma calculation
sigma = sqrt( length(masked_x)^(-2) * factor_sigma_sum );

% end calculateTheta5


%--------------------------------------------------------------------------
function [theta,sigma] = calculateTheta6 (image)
% calculate parameter theta in a part of an image (argin)
%assumption: argin image is a segment from whole image where values outside
%segment are zeros
% not taking into account pixels that have any zero pixels in neighborhood
% by: lrosz

% -------------------------------------------------------------------------
[h1,w1]=size(image);
img=double(image);


factor1=0;
factor2=0;
factor_sigma_sum=0;

[masked_x, masked_y] = find(image);
%[masked(:,1), masked(:,2)] = find(image);

for inmask = 1:length(masked_x)
    
    s(1) = masked_x(inmask);
    s(2) = masked_y(inmask);
    
    % neighbourhood of 's'
    Ns_coor = [s(1)-1, s(1), s(1)+1, s(2)-1, s(2), s(2)+1];
    
    %if it's on border 
    check = [ find(Ns_coor<=0), find(Ns_coor(1:3)>=h1), find(Ns_coor(4:6)>=w1) ];
    if ~isempty(check)
        ws=NaN;
    end
    
    %if its outside the mask 
    if img([s(1)-1,s(2)-1])==0 || img([s(1),s(2)-1])==0 ...
            || img([s(1)-1,s(2)])==0 || img([s(1)-1,s(2)+1])==0
        ws=NaN;
    end
    
end
    
    ws = [img(Ns_coor{1,2}(1),Ns_coor{1,2}(2)) ; img(Ns_coor{1,1}(1),Ns_coor{1,1}(2)) ; img(Ns_coor{2,1}(1),Ns_coor{2,1}(2)) ; img(Ns_coor{3,1}(1),Ns_coor{3,1}(2))];
    
    
    %if 'ws' is NaN it is border point and should not be taken into account
    if ~isnan(ws)
        %calculating theta
        tmp1=ws*ws';
        factor1=factor1+tmp1;
        tmp2=ws*img(s(1),s((2)));
        factor2=factor2+tmp2;
        
        %calculating sigma
        factor_sigma = (img(s(1),s(2)) - theta' * ws)^2;
        factor_sigma_sum=factor_sigma_sum+factor_sigma;
    end

    
%final theta calculation
theta=(((factor1)^(-1))*factor2);

%check if theta has 4 values if not first value is copied
%(need to return 'theta' as 1x4 matrix)
if numel(theta) ~= 4
    theta(2)=theta(1);
    theta(3)=theta(1);
    theta(4)=theta(1);
end

%final sigma calculation
sigma = sqrt( length(masked_x)^(-2) * factor_sigma_sum );

%end calculateTheta6
