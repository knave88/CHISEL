function out = block_one_roi (I, options)

createoptions_6;

%convert to double
I=double(I);

%% layer options

myI = lr_choose_layer (I, options.segmentation.layer);
if isempty(myI)
    out=[];
    return;
end


%% segm

out_segm = lr_tresh_bradley1(myI, options.segmentation.bradley.params.window, options.segmentation.bradley.params.T, options.segmentation.bradley.params.padding);
    
%ptional save
%lr_save_img2 (I_out, file, NaN, options.bradley);


%% post

out_post = p7_post (out_segm, options.postprocessing);
img_post = out_post.img;


%% refine & cluster_split
out_refine = p7_refine (myI, img_post, options);



%% 

out = out_refine;