function [FEAT_vector, s] = calc_feat_ver2 (img, mask, out_option)
% calculate features for neural network datasets
%
% input: img - one layer image such as grayscale
% mask - bw image where objests are 1 and background is 0
% out_option -
% ('all','2class_single','3class_single','2class_group','2class_group') -
% selects which features are outputed
% example: 
%           FEAT_vector = calc_feat_ver1 (rgb2gray(img), ~mask,'all');


s = regionprops(logical(mask), 'BoundingBox', 'PixelList','PixelIdxList');

if length(s) == 0
    FEAT_vector = [];
end

for k = 1:length(s)
    
    try
    
    if length(s(k).PixelList) < 5
        switch out_option
            case 'all'
            feat_numel = 103;
            FEAT_vector(:,k) = zeros(feat_numel,1);
        end
        continue;
    end
    
    %current_obj = extract_bb_new(img, s(k));
    current_obj_img = imcrop(img, s(k).BoundingBox);
    current_obj_mask = imcrop(mask, s(k).BoundingBox);
    
    % calculate features
    
    features_geo = regionprops(current_obj_mask, 'Area', 'MajorAxisLength', 'MinorAxisLength', 'Eccentricity', 'Orientation', 'FilledArea', 'EulerNumber', 'EquivDiameter', 'Solidity', 'Extent', 'Perimeter');
    
    features_glrlm = feat_glrlm (current_obj_img);
    
    features_grad = feat_grad (current_obj_img);
    
    features_hist = feat_hist (current_obj_img);
    
    features_haar = HaarWavEnFeat (current_obj_img);
    
    features_ar = feat_ar(current_obj_img);
    
    
    
    %vectorization
    
    features_hog_vec = HOG(current_obj_img);
    % #9
    
    features_hist_vec = cell2mat(struct2cell(features_hist));
    % #9
    
    features_grad_vec = cell2mat(struct2cell(features_grad));
    % #5
    
    temp_glrlm = cell2mat(squeeze(struct2cell(features_glrlm)))';
    features_glrlm_vec = temp_glrlm(:);
    % #44
    
    features_ar_vec = cell2mat(struct2cell(features_ar));
    % #5
    
    features_haar_vec = cell2mat(struct2cell(features_haar));
    % #20
    
    temp_geo = features_geo( find([features_geo.Area] == max([features_geo.Area]) ,1) );
    features_geo_vec = cell2mat(struct2cell(temp_geo));
    % #11

%end


% form output  %vectorize_nn_input
switch out_option
    case 'all'
        %feat_numel = length(features_hist_vec)+length(features_grad_vec)+length(features_glrlm_vec)+length(features_ar_vec)+length(features_haar_vec)+length(features_geo_vec)+length(features_hog_vec) ; 
        feat_numel = 103;
        %FEAT_vector = zeros(feat_numel , length(s));
        %for k = 1:length(s)
            FEAT_vector(:,k) = vertcat(features_hist_vec, features_grad_vec, features_glrlm_vec, features_ar_vec, features_haar_vec, features_geo_vec, features_hog_vec );
        %end
        
    case '2class_single'
        feat_numel = 6;
        %FEAT_vector = zeros(feat_numel , length(s));
        %for k = 1:length(s)
            FEAT_vector(:,k) = [features_glrlm_vec(15), features_haar_vec(19), features_grad_vec(2), features_hist_vec(5), features_hist_vec(2), features_glrlm_vec(4)];
        %end
        
    case '2class_group'
        feat_numel = length(features_glrlm_vec)+length(features_haar_vec)+length(features_grad_vec)+length(features_hist_vec);  % #78
        %FEAT_vector = zeros(feat_numel , length(s));
        %for k = 1:length(s)
            FEAT_vector(:,k) = vertcat(features_glrlm_vec, features_haar_vec, features_grad_vec, features_hist_vec);
        %end
        
    case '3class_single'
        feat_numel = 5;
        %FEAT_vector = zeros(feat_numel , length(s));
        %for k = 1:length(s)
            FEAT_vector(:,k) = [features_haar_vec(5), features_haar_vec(1), features_hist_vec(1), features_hist_vec(7), features_hist_vec(6)];
        %end
        
    case '3class_group'
        feat_numel = length(features_haar_vec)+length(features_hist_vec);  % #29
        %FEAT_vector = zeros(feat_numel , length(s));
        %for k = 1:length(s)
            FEAT_vector(:,k) = vertcat(features_haar_vec, features_hist_vec);
        %end
        
    otherwise
        feat_numel = 0;
        FEAT_vector(:,k) = zeros(feat_numel , length(s));
end

s(k).feat = FEAT_vector(:,k);

    catch ME
        disp(['Error',ME.message]);
        s(k).feat = zeros(92,1);
    end
end

%-------------------just in case-------------------------------------------
% alternative ways to extract objects form image

% function out_img = extract_obj (bw_img, s_1 )
% out_img = false(size(bw_img));
% 
% x = s_1.PixelList(:,1);
% y = s_1.PixelList(:,2);
% out_img(sub2ind(size(bw_img),y,x)) = 1;
% %out_img(s_1.PixelList) = true;
% 
% function [out_img, current_bb] = extract_bb(img, boundingBox, expand)
% imgSize = size(img);
% 
% if expand >= 0
%     bb1 = my_fix(boundingBox(1)-expand);
%     bb2 = my_fix(boundingBox(2)-expand); 
%     bb3 = ceil(boundingBox(1)+boundingBox(3)+expand);
%     bb4 = ceil(boundingBox(2)+boundingBox(4)+expand);
% 
%     current_bb = [bb1, bb2, bb3, bb4];
%     
%     if bb1<1 || bb2 < 1 || bb3 > imgSize(1) || bb4 > imgSize(2)
%         
%         pad_size_pre = [0 0];
%         pad_size_post = [0 0];
%         
%         if bb1<1
%             new_bb1 = 1;
%             %pad_size = [0 abs(bb1)];
%             pad_size_pre(2) = abs(bb1);
%             pad_dir = 'pre';
%         else
%             new_bb1 = bb1;
%         end
%         
%         if bb2<1
%             new_bb2 = 1;
%             %pad_size = [abs(bb2) 0];
%             pad_size_pre(1) = abs(bb2);
%             pad_dir = 'pre';
%         else
%             new_bb2 = bb2;
%         end
%         
%         if bb3 > imgSize(1)
%             new_bb3 = imgSize(1);
%             %pad_size = [0 abs(imgSize(1) - bb3)];
%             pad_size_post(2) = abs(imgSize(1) - bb3);
%             pad_dir = 'post';
%         else
%             new_bb3 = bb3;
%         end
%         
%         if bb4 > imgSize(2)
%             new_bb4 = imgSize(2);
%             %pad_size = [abs(imgSize(2) - bb4) 0];
%             pad_size_post(1) = abs(imgSize(2) - bb4);
%             pad_dir = 'post';
%         else
%             new_bb4 = bb4;
%         end
%         
%         current_bb = [new_bb1, new_bb2, new_bb3, new_bb4];
%         temp_img = img( current_bb(2) : current_bb(4), current_bb(1) : current_bb(3) );
%         
%         %pad_val = 0;
%         pad_val = 'symmetric';
%         
%         if bb1<1 || bb2<1
%             pad_dir = 'pre';
%             temp_img = padarray(temp_img, (pad_size_pre), pad_val, pad_dir);
%         end
%         if bb3 > imgSize(1) || bb4 > imgSize(2)
%             pad_dir = 'post';
%             temp_img = padarray(temp_img, (pad_size_post), pad_val, pad_dir);
%         end
%         out_img = temp_img;
%         
%     else
%         out_img = img( current_bb(2) : current_bb(4), current_bb(1) : current_bb(3) );
%     end
%     
% else
%     out_img = [];
% end
% 
% function output = my_fix (input)
% if input>=0
%     output = ceil(input);
% else
%     output = floor(input);
% end
% 
% function out = lr_fromIMcrop (a, spatial_rect) 
% %input: img, boundingBox
% 
% x = [1 size(a,2)];
% y = [1 size(a,1)];
% 
% m = size(a,1);
% n = size(a,2);
% xmin = min(x(:));
% ymin = min(y(:));
% xmax = max(x(:));
% ymax = max(y(:));
% 
% % Transform rectangle into row and column indices.
% if (m == 1)
%     pixelsPerVerticalUnit = 1;
% else
%     pixelsPerVerticalUnit = (m - 1) / (ymax - ymin);
% end
% if (n == 1)
%     pixelsPerHorizUnit = 1;
% else
%     pixelsPerHorizUnit = (n - 1) / (xmax - xmin);
% end
% 
% pixelHeight = spatial_rect(4) * pixelsPerVerticalUnit;
% pixelWidth = spatial_rect(3) * pixelsPerHorizUnit;
% r1 = (spatial_rect(2) - ymin) * pixelsPerVerticalUnit + 1;
% c1 = (spatial_rect(1) - xmin) * pixelsPerHorizUnit + 1;
% r2 = round(r1 + pixelHeight);
% c2 = round(c1 + pixelWidth);
% r1 = round(r1);
% c1 = round(c1);
% 
% % Check for selected rectangle completely outside the image
% if ((r1 > m) || (r2 < 1) || (c1 > n) || (c2 < 1))
%     %b = [];
%     out = [];
% else
%     r1 = max(r1, 1);
%     r2 = min(r2, m);
%     c1 = max(c1, 1);
%     c2 = min(c2, n);
%     %b = a(r1:r2, c1:c2, :);
%     out = [r1, r2, c1, c2];
% end
%--------------------------------------------------------------------------
