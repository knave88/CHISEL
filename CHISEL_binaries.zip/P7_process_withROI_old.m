function out_bw = P7_process_withROI_old (myI, options)

img_size = size(myI);

%base roi split
[roi_cell1, roi_pad1] = get_all_roi_v3 (img_size, options.roi.roi_size, 0);

%process base image with roi by roi method
base_result_img = process_withROI (myI, roi_cell1, roi_pad1, options); % #TODO

%get binary mask of overlapping
bw1 = logical( my_roi_mask (roi_cell1, img_size, options.roi.pad_filter_size) );

%results shifted by padding 
[roi_cell2a, roi_pad2a] = get_all_roi_v3h (img_size, options.roi.roi_size, options.roi.pad_filter_size);
[roi_cell2b, roi_pad2b] = get_all_roi_v3v (img_size, options.roi.roi_size, options.roi.pad_filter_size);
%process image
result_img2a = process_withROI (myI, roi_cell2a, roi_pad2a, options);
result_img2b = process_withROI (myI, roi_cell2b, roi_pad2b, options);

%use binary maps to know where to merge results
bw2a = logical( my_roi_mask (roi_cell2a, img_size, options.roi.pad_filter_size) );
bw2b = logical( my_roi_mask (roi_cell2b, img_size, options.roi.pad_filter_size) );

result_img2a_2merge = ~result_img2a .* bw2a;
result_img2b_2merge = ~result_img2b .* bw2b;


%results shifted (other sides)
[roi_cell3a, roi_pad3a] = get_all_roi_v3h (img_size, options.roi.roi_size, (options.roi.roi_size-options.roi.pad_filter_size) );
[roi_cell3b, roi_pad3b] = get_all_roi_v3v (img_size, options.roi.roi_size, (options.roi.roi_size-options.roi.pad_filter_size) );

%process image
result_img3a = process_withROI (myI, roi_cell3a, roi_pad3a, options);
result_img3b = process_withROI (myI, roi_cell3b, roi_pad3b, options);


bw3a = my_roi_mask (roi_cell3a, img_size, options.roi.pad_filter_size);
bw3a = logical(bw3a);

bw3b = my_roi_mask (roi_cell3b, img_size, options.roi.pad_filter_size);
bw3b = logical(bw3b);


try
result_img3a_2merge = ~result_img3a .* bw3a;
result_img3b_2merge = ~result_img3b .* bw3b;
catch ME
    ME.message
end

out_bw = ~base_result_img + result_img2a_2merge + result_img2b_2merge + result_img3a_2merge + result_img3b_2merge;



%% inside function
function I_out = process_withROI (myI, roi_cell, roi_pad, options)

for k = 1:length(roi_cell)
    if ~isempty(roi_cell{k})
        tmp_in = imcrop(myI, roi_cell{k});
        tmp_out = proc_one_roi (tmp_in, options);

        try
            I_out( roi_cell{k}(2):roi_cell{k}(2)+size(tmp_out,1)-1,  roi_cell{k}(1):roi_cell{k}(1)+size(tmp_out,2)-1 ) = tmp_out; % #TODO !temporary solution! do poprawy
        catch ME
            disp(['!!! ERROR !!! ___  ', ME.message]);
            I_out( roi_cell{k}(2):roi_cell{k}(2)+size(tmp_out,1)-1,  roi_cell{k}(1):roi_cell{k}(1)+size(tmp_out,2)-1 ) = zeros(size(tmp_in));
        end
    end
end

