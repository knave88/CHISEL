function [files_out, result_files, folder_name] = lr_tif_srch2a (f_dir, result_string)


%options.main.selection = 'file';
folder_name = [];
files_out = [];

switch f_dir
    case 'current_folder'
        my_files=dir;

    case 'select_folder'
        folder_name = uigetdir;
        if folder_name ~= 0
            my_files = dir(folder_name);
        else
            my_files = [];
        end
    
    case 'file'
        [FileName,PathName] = uigetfile('*.tif','Select the file');
        my_file = [PathName,FileName];
end



if strcmp(f_dir,'file')
    if regexpi(my_file, '.tif') %~isempty(strfind(my_file, '.tif'))
        files_out{1} = my_file;
    else
        files_out = cell(0);
    end
    return;
end
    
found = [];
for i=1:length(my_files)
    if regexpi(my_files(i).name, '.tif') %~isempty(strfind(my_files(i).name , '.tif'))
        found=[found, i];
    end
end

files_out = cell(0);
for j=1:length(found)
    files_out{j} = my_files(found(j)).name;
end


try
if ~isempty(files_out)
    result_files = dir_result_files (files_out, result_string);
else 
    result_files = [];
end

catch ME
    disp(['!Error occurred!  ',ME.message]);
    %files_out = [];
    result_files = [];
end

end % lr_tif_srch


function out = dir_result_files (files_out, result_string)
% find file with results
%result_string = '_P7result';

sel_files = find(~(cellfun(@isempty,strfind(files_out,result_string))));
if isempty(sel_files)
    out = [];
else
    
selected_files = files_out(sel_files);
selected_files_new = cell(size(selected_files));
k_new = 1;
for k = 1:length(selected_files)
    base_fname = [selected_files{k}(1:end-(4+length(result_string))),selected_files{k}(end-3:end)];
    
    temp1 = find(~(cellfun(@isempty,strfind(files_out,base_fname))));
    temp2 = find(~(cellfun(@isempty,strfind(files_out,selected_files{k}))));
    temp{k}= [temp1 temp2];
    
    if ~isempty(temp1)
        selected_files_new(k_new) = selected_files(k);
        k_new = k_new+1;
    end
    
end

k_new = 1;
for k = 1:length(temp)
    if numel(temp{k}) == 2
        files_out_with_results(k_new) = temp{k}(1);
        files_out_results(k_new) = temp{k}(2);
        k_new = k_new+1;
    end
end
files_out_rest = setdiff((1:length(files_out)), [files_out_with_results,files_out_results]);


%out_files_out_with_results = files_out(files_out_with_results);
%out_files_out_results = files_out(files_out_results);
%out_rest = files_out(setdiff((1:length(files_out)), [files_out_with_results,files_out_results]));

out.files_out_with_results = files_out_with_results;
out.files_out_results = files_out_results;
out.files_out_rest = files_out_rest;


%out = selected_files_new(~cellfun('isempty',selected_files_new));

end
end % dir_BW_files
