function varargout = p7_gui(varargin)
% P7_GUI MATLAB code for p7_gui.fig
%      P7_GUI, by itself, creates a new P7_GUI or raises the existing
%      singleton*.
%
%      H = P7_GUI returns the handle to a new P7_GUI or the handle to
%      the existing singleton*.
%
%      P7_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in P7_GUI.M with the given input arguments.
%
%      P7_GUI('Property','Value',...) creates a new P7_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before p7_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to p7_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help p7_gui

% Last Modified by GUIDE v2.5 20-Aug-2019 15:13:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @p7_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @p7_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before p7_gui is made visible.
function p7_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to p7_gui (see VARARGIN)

% Choose default command line output for p7_gui
handles.output = hObject;

columnname = {'Filename','Select','Size','Progress','Path'};
columnformat = {'char','logical','char','char','char'};
columneditable = [false, true, false, false, false];

set(handles.uitable1, 'ColumnName', columnname);
set(handles.uitable1, 'ColumnFormat', columnformat);
set(handles.uitable1, 'ColumnEdit', columneditable);
set(handles.uitable1, 'Data', []);

%set(handles.uitable1,'CellSelectionCallback',@uitable1_CellSelectionCallback)

handles.gui_val.img_prev = [];
handles.gui_val.img_post = [];

axes(handles.axes_prev);
imshow(handles.gui_val.img_prev);

axes(handles.axes_post);
imshow(handles.gui_val.img_post);

handles.gui_val.files = {};
handles.gui_val.selectedRow = [];
handles.gui_val.result_string = '_P7result';


options = p7_options;
handles.gui_val.options = options;

handles.gui_val.options.roi.select = true;
handles.gui_val.options.roi.parallel = false;
handles.gui_val.options.roi.gpu = false;


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes p7_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = p7_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in button_file.
function button_file_Callback(hObject, eventdata, handles)
% hObject    handle to button_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
FilterSpec={'*.tif;*.tiff;*.jp2','IMAGE Files (*.tif,*.tiff,*.jp2)';'*.tif;*.tiff',  'TIF images (*.tif,*.tiff)';'*.jp2',  'JPEG2000 (*.jp2)';'*.*',  'All Files (*.*)'};
[handles.gui_val.fileName,handles.gui_val.filePath] = uigetfile(FilterSpec,'File selector');

img_info = imfinfo([handles.gui_val.filePath,handles.gui_val.fileName]);
img_res = sprintf('%d x %d',img_info.Width, img_info.Height );

if handles.gui_val.fileName ~= 0
    
    TableData = get(handles.uitable1, 'Data');
    [my_files_rows, my_files_cols] = size(TableData);
    
    TableData{my_files_rows+1,1} = handles.gui_val.fileName;
    TableData{my_files_rows+1,2} = false;
    TableData{my_files_rows+1,3} = img_res;
    TableData{my_files_rows+1,4} = 'none';
    TableData{my_files_rows+1,5} = [handles.gui_val.filePath,handles.gui_val.fileName];
    
    set(handles.uitable1, 'Data', TableData);
    
else
    disp('No file selected!')

end

handles = getDataFromTable (handles);

guidata(hObject, handles);


% --- Executes on button press in button_folder.
function button_folder_Callback(hObject, eventdata, handles)
% hObject    handle to button_folder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[files_out, result_files, folder_name] = lr_tif_srch2a ('select_folder', handles.gui_val.result_string);

handles = getDataFromTable (handles);

if ~isempty(files_out)
    TableData = get(handles.uitable1, 'Data');
    [my_files_rows, my_files_cols] = size(TableData);
    
    
    for k = 1:length(files_out)
        
        temp_res_fname = find(~(cellfun(@isempty,strfind(files_out,[files_out{k}(1:end-4),handles.gui_val.result_string]))));
        
        img_info = imfinfo([folder_name,filesep,files_out{k}]);
        img_res = sprintf('%d x %d',img_info.Width, img_info.Height );

        
        TableData{my_files_rows+k,1} = files_out{k};
        TableData{my_files_rows+k,2} = false;
        TableData{my_files_rows+k,3} = img_res;
        
        if ~isempty(temp_res_fname)
            TableData{my_files_rows+k,4} = ['Result: ',files_out{temp_res_fname}];
        else
            TableData{my_files_rows+k,4} = 'none';
        end
        TableData{my_files_rows+k,5} = [folder_name,filesep,files_out{k}];
        
    end
    
    set(handles.uitable1, 'Data', TableData);
    
else
    disp('No proper files in selected folder!')
    
end

guidata(hObject, handles);


% --- Executes on button press in button_options.
function button_options_Callback(hObject, eventdata, handles)
% hObject    handle to button_options (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

h_pref = pref;
waitfor(h_pref);

filename_options = 'p7pref.mat';

if exist(filename_options,'file') == 2
    try
        load(filename_options);
        delete(filename_options);
    catch
        options = [];
    end
else
    options = [];
end

handles.gui_val.options = options;

guidata(hObject, handles);


% --- Executes on button press in checkbox_par.
function checkbox_par_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_par (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.gui_val.box_parallel = get(hObject,'Value');
handles.gui_val.options.roi.parallel = handles.gui_val.box_parallel;
guidata(hObject, handles);


% --- Executes on button press in checkbox_gpu.
function checkbox_gpu_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_gpu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.gui_val.box_gpu = get(hObject,'Value');
handles.gui_val.options.roi.gpu = handles.gui_val.box_gpu;
guidata(hObject, handles);



% --- Executes on button press in button_remove.
function button_remove_Callback(hObject, eventdata, handles)
% hObject    handle to button_remove (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

TableData = get(handles.uitable1, 'Data');
my_remove = ~([TableData{:,2}]');

TableData_new = TableData(my_remove,:);

set(handles.uitable1, 'Data', TableData_new);

guidata(hObject, handles);


% --- Executes on button press in button_process.
function button_process_Callback(hObject, eventdata, handles)
% hObject    handle to button_process (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try

TableData = get(handles.uitable1, 'Data');
my_process = [TableData{:,2}]';
filesToProcess = [TableData(my_process,:)];

idx_my_process = find(my_process);

for k = 1:length(idx_my_process)
    myinfo = imfinfo(TableData{idx_my_process(k),5});
        
    if myinfo.SamplesPerPixel == 3
        if isempty(strfind(TableData{idx_my_process(k),4}, 'none'))
            choice = ovrWriteDlg (TableData{idx_my_process(k),1},TableData{idx_my_process(k),4});
            if choice
                TableData{idx_my_process(k),4} = 'Processing...';
                set(handles.uitable1, 'Data', TableData);
                drawnow;
                out_temp{k} = P7_process_image (TableData{idx_my_process(k),5}, handles.gui_val.options);
                TableData{idx_my_process(k),4} = ['Finished: ', out_temp{k}];
                set(handles.uitable1, 'Data', TableData);
                drawnow;
            end
        else
            TableData{idx_my_process(k),4} = 'Processing...';
            set(handles.uitable1, 'Data', TableData);
            drawnow;
            out_temp{k} = P7_process_image (TableData{idx_my_process(k),5}, handles.gui_val.options);
            TableData{idx_my_process(k),4} = ['Finished: ', out_temp{k}];
            set(handles.uitable1, 'Data', TableData);
            drawnow;
        end
        
    else
        TableData{idx_my_process(k),4} = 'File could not be processed.';
        set(handles.uitable1, 'Data', TableData);
    end 
end
catch ME
    errString = ['Error: ', ME.message];
    disp(errString);
    h_errBox = msgbox(errString, 'Error','error');
end
    
guidata(hObject, handles);

% --- Executes on button press in button_process.
function button_preview_Callback(hObject, eventdata, handles)
% hObject    handle to button_process (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if ~isempty(handles.gui_val.selectedRow)
    
    TableData = get(handles.uitable1, 'Data');
    
    my_fname = TableData{handles.gui_val.selectedRow,5};
    
    my_imfinfo = imfinfo(my_fname);
    
    if my_imfinfo.Width > 3000 || my_imfinfo.Height > 3000 
        disp('image too big for preview')
        
        toobigimage = imread('img2big.png');
        
        axes(handles.axes_prev);
        imshow(toobigimage);
        
        axes(handles.axes_post);
        imshow([]);
        
        
    elseif isempty(strfind(TableData{handles.gui_val.selectedRow,4}, 'none'))
        
        img = imread(my_fname);
        axes(handles.axes_prev);
        imshow(img);
        
        [tmp, img_result_fname] = strtok(TableData{handles.gui_val.selectedRow,4}, ' ');
        img_result_path = TableData{handles.gui_val.selectedRow,5};
        img_result_path = img_result_path(1:end-length(TableData{handles.gui_val.selectedRow,1}));
        img_result_path = [img_result_path, img_result_fname(2:end)];
        if ~isempty(img_result_fname)
            img_result = imread(img_result_path);
            axes(handles.axes_post);
            imshow(img_result);
        end
        
    else
        img = imread(my_fname);
        axes(handles.axes_prev);
        imshow(img);
        
        axes(handles.axes_post);
        imshow([]);
    end
    %img = imload
    
    
end

guidata(hObject, handles);



% --- Executes on button press in button_select.
function button_select_Callback(hObject, eventdata, handles)
% hObject    handle to button_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
TableData = get(handles.uitable1, 'Data');
if ~isempty(TableData)
    out = selectDlg (handles);
end

guidata(hObject, handles);



function uitable1_CellSelectionCallback(hObject, eventdata, handles)

[m n] = size(eventdata.Indices);

if m>1
    warndlg('Please select only one file for preview','! Warning !');
end

if ~isempty(eventdata.Indices)
    row = eventdata.Indices(1,1);
else
    row = [];
end
%col = eventdata.Indices(2);
%disp(handles)

handles.gui_val.selectedRow = row;
guidata(hObject, handles);



function handles = updateGuiTable (hObject,handles)

handles.gui_val.objects = handles.gui_val.objects(index); 
clear index


for i = 1: numel(handles.gui_val.objects)
    propertiesT{i,1} = handles.gui_val.objects(i).punchNum;

    if handles.gui_val.objects(i).validTable
        propertiesT{i,2} = true;
    else
        propertiesT{i,2} = false;
    end
    %propertiesT{i,3} = bb2str(handles.gui_val.objects(i).BoundingBox);
end

set(handles.uitable_obj, 'Data', propertiesT);

guidata(hObject, handles);



function handles = getDataFromTable (handles)

TableData = get(handles.uitable1, 'Data');
if ~isempty(TableData)
    %handles.gui_val.files(:,1) = TableData(:,1);
    %handles.gui_val.files(:,2) = TableData(:,5);
    handles.gui_val.files = TableData;
    handles.gui_val.files(:,2:4) = [];
end


function out = ovrWriteDlg (fname,result_fname)
choice = questdlg(['The file', fname,' already has a ',result_fname,', would you like to overwrite it?'], ...
	'Overwrite?', ...
	'Yes','No','No');
% Handle response
switch choice
    case 'Yes'
        out = true;
    case 'No'
        out = false;
    otherwise
        out = false;
end


function out = selectDlg (handles)
choice = questdlg(['The file',' already has a ',', would you like to overwrite it?'], ...
	'Selection', ...
	'Select all','Select results','Select none','Select all');
% Handle response
switch choice
    case 'Select all'
        TableData = get(handles.uitable1, 'Data');
        for k = 1:size(TableData,1)
            TableData{k,2} = true;
        end
        set(handles.uitable1, 'Data', TableData);
        out = true;
        
    case 'Select results'
        TableData = get(handles.uitable1, 'Data');
        for k = 1:size(TableData,1)
            img_name = TableData{k,1};
            if isempty(strfind(img_name, handles.gui_val.result_string))
                TableData{k,2} = false;
            else
                TableData{k,2} = true;
            end
        end
        set(handles.uitable1, 'Data', TableData);
        out = true;
        
    case 'Select none'
        TableData = get(handles.uitable1, 'Data');
        for k = 1:size(TableData,1)
            TableData{k,2} = false;
        end
        set(handles.uitable1, 'Data', TableData);
        out = true;
        
    otherwise
        out = false;
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over checkbox_par.
function checkbox_par_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to checkbox_par (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

