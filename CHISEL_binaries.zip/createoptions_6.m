% create options
%last edit: 30.01.2018

options.main.selection = 'current_folder';
%options.main.selection = 'select_folder';
%options.main.selection = 'file';

options.main.roi_process = true;

options.main.segmentation = false;
options.main.postprocessing = false;
options.main.refine_boundary = true;
options.main.grading = false;
options.main.BA = false;
options.main.scoring = false;


%choose one layer:
options.segmentation.layer.bratio = false;
options.segmentation.layer.brown = false;
options.segmentation.layer.deconv_DAB = false;
options.segmentation.layer.deconv_H = false;
options.segmentation.layer.hsv = true;
options.segmentation.layer.red = false;

%roi options:
options.roi.roi_size = 1000; 
options.roi.pad_filter_size = 151;
options.roi.evalNN = true; 

%segmentation options
save_file = true;
save_fig = false;
show = false;

options.segmentation.cut = 0;
options.segmentation.c_val = [10];
%options.segmentation.c_val = [10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180];

border_value = 0; % postprocessing optional border cut


%% seg methods
options.segmentation.niblack.do = false;
options.segmentation.sauvola.do = false;
options.segmentation.white.do = false;
options.segmentation.bernsen.do = false;
options.segmentation.palumbo.do = false;
options.segmentation.yasuda.do = false;

options.segmentation.bradley.do = true;
options.segmentation.nick.do = false;
options.segmentation.wolf.do = false;

options.segmentation.feng.do = false;

options.segmentation.kapur.do = false;
options.segmentation.kittler.do = false;

options.segmentation.entropy.do = false;
options.segmentation.mce.do = false; 
options.segmentation.met.do = false; 
options.segmentation.maxent.do = false; 

options.segmentation.fuzzy.do = false;
options.segmentation.fuzzcc.do = false;

options.segmentation.otsu.do = false;

options.segmentation.own.do = false;


%% niblack
options.segmentation.niblack.save_file = save_file;
options.segmentation.niblack.save_fig = save_fig;
options.segmentation.niblack.show = show;
options.segmentation.niblack.params.method = 'niblack';
options.segmentation.niblack.params.k = -0.2;
options.segmentation.niblack.params.hood_size = 51;

%% sauvola
options.segmentation.sauvola.save_file = save_file;
options.segmentation.sauvola.save_fig = save_fig;
options.segmentation.sauvola.show = show;
options.segmentation.sauvola.params.method = 'sauvola';
options.segmentation.sauvola.params.k = -0.2;
options.segmentation.sauvola.params.R = 128;
options.segmentation.sauvola.params.hood_size = 51;

%% white
options.segmentation.white.save_file = save_file;
options.segmentation.white.save_fig = save_fig;
options.segmentation.white.show = show;
options.segmentation.white.params.method = 'white';
options.segmentation.white.params.bias = 2;
options.segmentation.white.params.hood_size = 51;

%% bernsen
options.segmentation.bernsen.save_file = save_file;
options.segmentation.bernsen.save_fig = save_fig;
options.segmentation.bernsen.show = show;
options.segmentation.bernsen.params.method = 'bernsen';
options.segmentation.bernsen.params.in_eq = '>=';
options.segmentation.bernsen.params.hood_size = 51;

%% palumbo
options.segmentation.palumbo.save_file = save_file;
options.segmentation.palumbo.save_fig = save_fig;
options.segmentation.palumbo.show = show;
options.segmentation.palumbo.params.method = 'palumbo';
options.segmentation.palumbo.params.t1 = 20;
options.segmentation.palumbo.params.t3 = 0.85;
options.segmentation.palumbo.params.hood_size = 51;

%% yasuda
options.segmentation.yasuda.save_file = save_file;
options.segmentation.yasuda.save_fig = save_fig;
options.segmentation.yasuda.show = show;
options.segmentation.yasuda.params.method = 'yasuda';
options.segmentation.yasuda.params.t1 = 50;
options.segmentation.yasuda.params.t2 = 100;
options.segmentation.yasuda.params.t3 = 128;
options.segmentation.yasuda.params.t4 = 15;
options.segmentation.yasuda.params.f3_hood = 51;

%% bradley
options.segmentation.bradley.save_file = save_file;
options.segmentation.bradley.save_fig = save_fig;
options.segmentation.bradley.show = show;
options.segmentation.bradley.params.method = 'bradley';
options.segmentation.bradley.params.window = [151 151];
options.segmentation.bradley.params.T = 5;
options.segmentation.bradley.params.padding = 'replicate';

%% feng
options.segmentation.feng.save_file = save_file;
options.segmentation.feng.save_fig = save_fig;
options.segmentation.feng.show = show;
options.segmentation.feng.params.method = 'feng';
options.segmentation.feng.params.window = [51 51];
options.segmentation.feng.params.windowBig = [71 71];
options.segmentation.feng.params.alpha = 0.12;
options.segmentation.feng.params.gamma = 2;
options.segmentation.feng.params.k1 = 0.25;
options.segmentation.feng.params.k2 = 0.04;
options.segmentation.feng.params.padding = 'replicate';

%% kapur
options.segmentation.kapur.save_file = save_file;
options.segmentation.kapur.save_fig = save_fig;
options.segmentation.kapur.show = show;
options.segmentation.kapur.params.method = 'kapur'; %local takes too long!
options.segmentation.kapur.params.hood_size = 51;
% number of thresholds: 1

%% kittler
options.segmentation.kittler.save_file = save_file;
options.segmentation.kittler.save_fig = save_fig;
options.segmentation.kittler.show = show;
options.segmentation.kittler.params.method = 'kittler';
options.segmentation.kittler.params.hood_size = 51;

%% nick
options.segmentation.nick.save_file = save_file;
options.segmentation.nick.save_fig = save_fig;
options.segmentation.nick.show = show;
options.segmentation.nick.params.method = 'nick';
options.segmentation.nick.params.window = [15 15];
options.segmentation.nick.params.k = -0.01;
options.segmentation.nick.params.padding = 'replicate';

%% wolf
options.segmentation.wolf.save_file = save_file;
options.segmentation.wolf.save_fig = save_fig;
options.segmentation.wolf.show = show;
options.segmentation.wolf.params.method = 'wolf';
options.segmentation.wolf.params.window = [151 151];
options.segmentation.wolf.params.k = 0.01;
options.segmentation.wolf.params.padding = 'replicate';

%% entropy
options.segmentation.entropy.save_file = save_file;
options.segmentation.entropy.save_fig = save_fig;
options.segmentation.entropy.show = show;
options.segmentation.entropy.params.method = 'entropy';
options.segmentation.entropy.params.hood_size = 51;

%% mce
options.segmentation.mce.save_file = save_file;
options.segmentation.mce.save_fig = save_fig;
options.segmentation.mce.show = show;
options.segmentation.mce.params.method = 'mce';
options.segmentation.mce.params.hood_size = 51;

%% met
options.segmentation.met.save_file = save_file;
options.segmentation.met.save_fig = save_fig;
options.segmentation.met.show = show;
options.segmentation.met.params.method = 'met';
options.segmentation.met.params.hood_size = 51;

%% maxent
options.segmentation.maxent.save_file = save_file;
options.segmentation.maxent.save_fig = save_fig;
options.segmentation.maxent.show = show;
options.segmentation.maxent.params.method = 'maxent';
options.segmentation.maxent.params.hood_size = 51;

%% fuzzy
options.segmentation.fuzzy.save_file = save_file;
options.segmentation.fuzzy.save_fig = save_fig;
options.segmentation.fuzzy.show = show;
options.segmentation.fuzzy.params.method = 'fuzzy';
options.segmentation.fuzzy.params.nthresh = 1;
options.segmentation.fuzzy.params.hood_size = 151;

%% fuzzcc
options.segmentation.fuzzcc.save_file = save_file;
options.segmentation.fuzzcc.save_fig = save_fig;
options.segmentation.fuzzcc.show = show;
options.segmentation.fuzzcc.params.method = 'fuzzcc';
options.segmentation.fuzzcc.params.sw = 0; %0 or 1
options.segmentation.fuzzcc.params.hood_size = 151;

%% otsu
options.segmentation.otsu.save_file = save_file;
options.segmentation.otsu.save_fig = save_fig;
options.segmentation.otsu.show = show;
options.segmentation.otsu.params.method = 'otsu';
options.segmentation.otsu.params.hood_size = 51;

%% own1
options.segmentation.own.save_file = save_file;
options.segmentation.own.save_fig = save_fig;
options.segmentation.own.show = show;
options.segmentation.own.params.method = 'own';
options.segmentation.own.params.window = [51 51];
options.segmentation.own.params.windowBig = [151 151];
options.segmentation.own.params.T = 5;
options.segmentation.own.params.k = -0.01;
options.segmentation.own.params.padding = 'replicate';


%% postprocessing
options.postprocessing.discrimination_size = true;
options.postprocessing.discrimination_border = false;
options.postprocessing.discrimination_roundness = false;
options.postprocessing.discrimination_solidity = false;

options.postprocessing.presentObj = false;
options.postprocessing.calculateEdge = false; % wykuczenie Optimization_Toolbox z uwagi na ograniczone licencje
options.postprocessing.presentEdge = false;
options.postprocessing.presentRoundness = false;
options.postprocessing.presentOut = false;
options.postprocessing.saveOut = true;
options.postprocessing.printError = false;
options.postprocessing.T_size = [50 10000]; % [50 10000];

options.postprocessing.border.save = false;
options.postprocessing.border.value = border_value;

options.postprocessing.inverseFinding = true;
options.postprocessing.solidThresh = [0.4 Inf];
options.postprocessing.roundThresh = [-Inf Inf];

%% bw image
options.true_BW.BWpostprocessed = false;
options.true_BW.discrimination_size = options.postprocessing.discrimination_size;
options.true_BW.discrimination_border = options.postprocessing.discrimination_border;
options.true_BW.presentObj = false;
options.true_BW.calculateEdge = false; % wykuczenie Optimization_Toolbox z uwagi na ograniczone licencje
options.true_BW.presentEdge = false;
options.true_BW.presentRoundness = false;
options.true_BW.presentOut = false;
options.true_BW.saveOutObj = false;
options.true_BW.printError = false;
options.true_BW.T_size = options.postprocessing.T_size;
options.true_BW.saveOut = true; % better - false
options.true_BW.border.value = border_value;
options.true_BW.border.save = true;

options.true_BW.multi = true;
options.true_BW.type = [];
options.true_BW.numel = 0;
options.true_BW.selective_bw = true;


%% refine_boundary
options.refine.only_postprocessed = true;
options.refine.refine_method = 11; %(11)    0 1 11 2 22 3 4 5 6 8 (0 = just filling holes)
options.refine.show = false;
options.refine.show_out = false;
options.refine.save = true;
options.refine.expand = 0;
options.refine.refine_size_thresh = 20; %25


% refine_method 1
options.refine.ms.params.rad = 11; % 51
options.refine.ms.params.alpha = 0.003; %def 0.03 % coefficient of the length term
options.refine.ms.params.num_it = 20; %def 100
options.refine.ms.params.epsilon = 0.02; % def 1

% refine_method 2
options.refine.um.params.rad = 51;
options.refine.um.params.alpha = 0.03; % coefficient of the length term
options.refine.um.params.num_it = 100;
options.refine.um.params.epsilon = 1;

% refine_method 3
%options.refine.cv.params.mask_init = 'medium'; % small medium large whole whole+small
options.refine.cv.params.num_iter = 20; % def 1000
options.refine.cv.params.mu = 0.2; %def 0.2 % weight of length term
options.refine.cv.params.method = 'chan'; %('chan','vector','multiphase')

% cluster splitting
options.refine.cluster.when = 'after'; % before after after2 none middle
options.refine.cluster.method = 'DT'; % waterSeeded, DT, Hminima, huang, mouelhi, kong, none (method = none turns off splitting)
options.refine.cluster.show = false;

options.refine.cluster.kong.do = true;
options.refine.cluster.kong.visualize1 = false;
options.refine.cluster.kong.visualize2 = false;
options.refine.cluster.kong.visualize3 = false;

options.refine.cluster.mouelhi.T_min_ridge_length = 3;
options.refine.cluster.mouelhi.T_eucDist = 15;
options.refine.cluster.mouelhi.visualize1 = false;
options.refine.cluster.mouelhi.visualize2 = false;

options.refine.cluster.waterseeded.visualize1 = false;
options.refine.cluster.waterseeded.gradientOnBW = true;

options.refine.cluster.dt.visualize1 = false;
options.refine.cluster.dt.T = 0.55; % 0.6
options.refine.cluster.dt.gradientOnBW = true;

options.refine.cluster.hminima.visualize1 = false;
options.refine.cluster.hminima.T = 0.8;
options.refine.cluster.hminima.gradientOnBW = true;

options.refine.cluster.huang.visualize1 = false;
options.refine.cluster.huang.gradientOnBW = true;
%options.refine.cluster.huang

%% grading
options.grade.only_postprocessed = true;
options.grade.only_bordered = false;
options.grade.showResult = false;
options.grade.saveFile = true;
options.grade.saveFileName = 'out_grade';
options.grade.saveWparams = true;
options.grade.saveFileHour = true;

%options.grade.border = 51;
%options.grade.saveBorderOut = true;

options.grade.layer = options.segmentation.layer;

%% BA plot
options.ba.only_postprocessed = true;
options.ba.only_bordered = false;
options.ba.showResult = false;
options.ba.saveFile = true;
options.ba.saveFileName = 'out_ba_cum';
options.ba.expand = 0;
options.ba.field_names = {'Area', 'Perimeter', 'Eccentricity','Solidity','Roundness','AxisRatio'};
options.ba.layer = options.segmentation.layer;
options.ba.invert = false;


%% scoring  obj-obj
options.score.only_postprocessed = true;
options.score.only_refined = true;
options.score.only_bordered = false;
options.score.layer = options.segmentation.layer;
options.score.multi = true;
options.score.saveFile = true;
options.score.saveFileName = 'out_score';
options.score.saveFileHour = true;

options.score.T_dist = 0;


%% clear
clear save_fig save_file show border_value