function newFilename = P7_process_image (filename, options)

if ~isempty(strfind(filename, '_post')) || ~isempty(strfind(filename, '_BW')) || ~isempty(strfind(filename, '_SCORE')) || ~isempty(strfind(filename, '_new'))
    I_out=[];
    return
end 

file_info = imfinfo(filename);
img2_size = [file_info.Width, file_info.Height];

[userview,systemview] = memory;

disp(['processing file: ',filename]);
tic
if file_info.FileSize > 3e+8 %(userview.MaxPossibleArrayBytes-userview.MemUsedMATLAB)*0.1 < file_info.FileSize
    %load roi by roi into memory
    disp('processing... loading roi by roi into memory')
    newFilename = proc_image_block(filename, options);
else
    %load whole image into memory
    disp('processing... loading whole image into memory')
    I_out = proc_image_whole(filename, options);
    
    [fpath,fname,fext] = fileparts(filename);
    newFilePath = [fpath,filesep,fname,'_P7result',fext];
    newFilename = [fname,'_P7result',fext];
    imwrite(uint8(I_out).*100,newFilePath);
    
end
disp(num2str(toc))


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------


function newFilename = proc_image_block(filename, options)

[pathstr,name,ext] = fileparts(filename) ;
file_info = imfinfo(filename);
img_size = [file_info.Width, file_info.Height];
%userview = memory;

%temp_block_size = floor(sqrt(userview.MaxPossibleArrayBytes) / 9);
%temp_block_size = 1000;
temp_block_size = options.roi.roi_size;

fun = @(block_struct) (proc_one_block(block_struct.data, options));

newFilePath = [pathstr,filesep,name,'_P7result',ext];
newFilename = [name,'_P7result',ext];

%blockproc(filename,[temp_block_size temp_block_size],fun, 'Destination',newFilename); %#TODO blockproc & ImageAdapter (moze da sie zapisac nie jako tiled tif)
%w blockproc mozna ustawic UseParallel

if options.roi.parallel
    blockproc(filename,[temp_block_size temp_block_size],fun, 'Destination',newFilePath,'UseParallel',true);
else
    blockproc(filename,[temp_block_size temp_block_size],fun, 'Destination',newFilePath,'UseParallel',false);
end
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

