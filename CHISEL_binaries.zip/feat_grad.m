function out = feat_grad (img)

[m,n] = size(img);

M = m*n; % numer of elements

[Gmag,Gdir] = imgradient(img, 'CentralDifference');

GRMean = sum(sum( Gmag(:) ))/M ;

GrVariance = sum(sum(  (Gmag(:)-GRMean).^2  ))/M ;

GrSkewness = ( 1/ (sqrt(GrVariance)).^3 )*(sum(sum(  (Gmag(:)-GRMean).^3  ))/M );

GrKurtosis = ( 1/ (sqrt(GrVariance)).^4 )*(sum(sum(  (Gmag(:)-GRMean).^4  ))/M ) -3;

GrNonZeros = (length(find(Gmag))/M) ;

out.GRMean = GRMean;
out.GrVariance = GrVariance;
out.GrSkewness = GrSkewness;
out.GrKurtosis = GrKurtosis;
out.GrNonZeros = GrNonZeros;