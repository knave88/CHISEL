function varargout = pref(varargin)
% PREF MATLAB code for pref.fig
%      PREF, by itself, creates a new PREF or raises the existing
%      singleton*.
%
%      H = PREF returns the handle to a new PREF or the handle to
%      the existing singleton*.
%
%      PREF('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PREF.M with the given input arguments.
%
%      PREF('Property','Value',...) creates a new PREF or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before pref_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to pref_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help pref

% Last Modified by GUIDE v2.5 19-Aug-2019 17:16:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pref_OpeningFcn, ...
                   'gui_OutputFcn',  @pref_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before pref is made visible.
function pref_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to pref (see VARARGIN)

% Choose default command line output for pref
handles.output = hObject;

options = set_options ();

set(handles.pop_layer, 'String', options.segmentation.layer.list);
set(handles.pop_layer, 'Value', options.segmentation.layer.idx);

set(handles.but_par, 'Value', options.roi.parallel);
if options.roi.parallel
    set(handles.but_par, 'String', 'ON');
else
    set(handles.but_par, 'String', 'OFF');
end

set(handles.but_gpu, 'Value', options.roi.gpu);
if options.roi.gpu
    set(handles.but_gpu, 'String', 'ON');
else
    set(handles.but_gpu, 'String', 'OFF');
end


set(handles.pop_data, 'String', options.refine.cluster.list);
set(handles.pop_data, 'Value', options.refine.cluster.idx);

set(handles.but_roi, 'Value', options.roi.select);
if options.roi.select
    set(handles.but_roi, 'String', 'ON');
else
    set(handles.but_roi, 'String', 'OFF');
end

set(handles.edit_roisize, 'String', num2str(options.roi.roi_size));
set(handles.edit_roipad, 'String', num2str(options.roi.pad_filter_size) );

set(handles.edit_window, 'String', num2str(options.segmentation.bradley.params.window(1)) );
set(handles.edit_segmT, 'String', num2str(options.segmentation.bradley.params.T) );

set(handles.edit_size1, 'String', num2str(options.postprocessing.T_size(1)) );
set(handles.edit_size2, 'String', num2str(options.postprocessing.T_size(2)) );
set(handles.edit_solid1, 'String', num2str(options.postprocessing.solidThresh(1)) );
set(handles.edit_solid2, 'String', num2str(options.postprocessing.solidThresh(2)) );

set(handles.edit_clusterT, 'String', num2str(options.refine.cluster.dt.T) );
set(handles.edit_maxrecur, 'String', num2str(options.refine.cluster.max_recurr) );


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes pref wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = pref_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in but_roi.
function but_roi_Callback(hObject, eventdata, handles)
% hObject    handle to but_roi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
temp = get(hObject,'Value');

if temp 
    set(hObject,'String', 'ON');
else
    set(hObject,'String', 'OFF');
end
guidata(hObject, handles);


function edit_roisize_Callback(hObject, eventdata, handles)
% hObject    handle to edit_roisize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_roisize as text
%        str2double(get(hObject,'String')) returns contents of edit_roisize as a double


% --- Executes during object creation, after setting all properties.
function edit_roisize_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_roisize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_roipad_Callback(hObject, eventdata, handles)
% hObject    handle to edit_roipad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_roipad as text
%        str2double(get(hObject,'String')) returns contents of edit_roipad as a double


% --- Executes during object creation, after setting all properties.
function edit_roipad_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_roipad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pop_layer.
function pop_layer_Callback(hObject, eventdata, handles)
% hObject    handle to pop_layer (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pop_layer contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_layer


% --- Executes during object creation, after setting all properties.
function pop_layer_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_layer (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in but_par.
function but_par_Callback(hObject, eventdata, handles)
% hObject    handle to but_par (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
temp = get(hObject,'Value');

if temp 
    set(hObject,'String', 'ON');
else
    set(hObject,'String', 'OFF');
end
guidata(hObject, handles);


% --- Executes on button press in but_gpu.
function but_gpu_Callback(hObject, eventdata, handles)
% hObject    handle to but_gpu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

temp = get(hObject,'Value');

if temp 
    set(hObject,'String', 'ON');
else
    set(hObject,'String', 'OFF');
end
guidata(hObject, handles);


% --- Executes on selection change in pop_data.
function pop_data_Callback(hObject, eventdata, handles)
% hObject    handle to pop_data (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pop_data contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_data


% --- Executes during object creation, after setting all properties.
function pop_data_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_data (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_size1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_size1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_size1 as text
%        str2double(get(hObject,'String')) returns contents of edit_size1 as a double


% --- Executes during object creation, after setting all properties.
function edit_size1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_size1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_size2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_size2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_size2 as text
%        str2double(get(hObject,'String')) returns contents of edit_size2 as a double


% --- Executes during object creation, after setting all properties.
function edit_size2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_size2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_solid1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_solid1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_solid1 as text
%        str2double(get(hObject,'String')) returns contents of edit_solid1 as a double


% --- Executes during object creation, after setting all properties.
function edit_solid1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_solid1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_solid2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_solid2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_solid2 as text
%        str2double(get(hObject,'String')) returns contents of edit_solid2 as a double


% --- Executes during object creation, after setting all properties.
function edit_solid2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_solid2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_clusterT_Callback(hObject, eventdata, handles)
% hObject    handle to edit_clusterT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_clusterT as text
%        str2double(get(hObject,'String')) returns contents of edit_clusterT as a double


% --- Executes during object creation, after setting all properties.
function edit_clusterT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_clusterT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_maxrecur_Callback(hObject, eventdata, handles)
% hObject    handle to edit_maxrecur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_maxrecur as text
%        str2double(get(hObject,'String')) returns contents of edit_maxrecur as a double


% --- Executes during object creation, after setting all properties.
function edit_maxrecur_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_maxrecur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_window_Callback(hObject, eventdata, handles)
% hObject    handle to edit_window (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_window as text
%        str2double(get(hObject,'String')) returns contents of edit_window as a double


% --- Executes during object creation, after setting all properties.
function edit_window_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_window (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_segmT_Callback(hObject, eventdata, handles)
% hObject    handle to edit_segmT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_segmT as text
%        str2double(get(hObject,'String')) returns contents of edit_segmT as a double


% --- Executes during object creation, after setting all properties.
function edit_segmT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_segmT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_apply.
function pushbutton_apply_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
options = p7_options;
options = get_options(handles,options);

save('p7pref.mat','options'); % #TODO 
% przekazanie danych miedzy gui przez zapis zmiennej do pliku
% na pewno mozna to zrobic lepiej ale z uiwait/resume nie wychodzi mi teraz

close(handles.figure1);


% --- Executes on button press in pushbutton_cancel.
function pushbutton_cancel_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_cancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

close(handles.figure1);



function options = set_options ()

options.segmentation.layer.bratio = false;
options.segmentation.layer.brown = false;
options.segmentation.layer.deconv_DAB = false;
options.segmentation.layer.deconv_H = false;
options.segmentation.layer.hsv = true;
options.segmentation.layer.red = false;

myLayer = choose_layer (options.segmentation.layer);
list_layer = {'(R)GB','HS(V)','H - color deconv.','DAB - color deconv.','Blue ratio', 'Brown'};
options.segmentation.layer.idx = find(ismember(list_layer, myLayer));
options.segmentation.layer.list = list_layer;

options.roi.parallel = false;
options.roi.gpu = false;

options.refine.cluster.list = {'DAB&H','H&E','Synthetic','Other'};
options.refine.cluster.idx = 1;

options.roi.select = true; 
options.roi.roi_size = 1000; 
options.roi.pad_filter_size = 151;

options.segmentation.bradley.params.method = 'bradley';
options.segmentation.bradley.params.window = [151 151];
options.segmentation.bradley.params.T = 5;
options.segmentation.bradley.params.padding = 'replicate';

options.postprocessing.T_size = [50 10000];
options.postprocessing.solidThresh = [0.4 Inf];

options.refine.cluster.dt.T = 0.55;
options.refine.cluster.max_recurr = 7; % IISPV (7) / BBBC004 (30)


function options = get_options (handles,options)
options.segmentation.layer.list = get(handles.pop_layer, 'String');
options.segmentation.layer.idx = get(handles.pop_layer, 'Value');


options.roi.parallel = get(handles.but_par, 'Value');
options.roi.gpu = get(handles.but_gpu, 'Value');
options.refine.cluster.list = get(handles.pop_data, 'String');
options.refine.cluster.idx = get(handles.pop_data, 'Value');

options.refine.cluster.list_sel = choose_dataset (handles);
switch options.refine.cluster.list_sel
    case 'DAB&H' %'IISPV' 
        options.refine.cluster.dataset = 'IISPV';
        options.refine.cluster.max_recurr = 7; % IISPV (7) / BBBC004 (30)
    case 'Synthetic'%'BBBC004'
        options.refine.cluster.dataset = 'BBBC004';
        options.refine.cluster.max_recurr = 30; % IISPV (7) / BBBC004 (30)
    case 'H&E' % #TODO
        options.refine.cluster.dataset = 'TBD';
        options.refine.cluster.max_recurr = 7;
    otherwise
        options.refine.cluster.dataset = 'TBD';
        options.refine.cluster.max_recurr = 7;
end

options.roi.select = get(handles.but_roi, 'Value');

options.roi.roi_size = str2double(get(handles.edit_roisize, 'String'));
options.roi.pad_filter_size = str2double(get(handles.edit_roipad, 'String'));

window = str2double(get(handles.edit_window, 'String'));
options.segmentation.bradley.params.window = [window window];

options.segmentation.bradley.params.T = str2double(get(handles.edit_segmT, 'String'));

T_size1 = str2double(get(handles.edit_size1, 'String'));
T_size2 = str2double(get(handles.edit_size2, 'String'));
options.segmentation.bradley.params.T_size = [T_size1 T_size2];

solidThresh1 = str2double(get(handles.edit_solid1, 'String') );
solidThresh2 = str2double(get(handles.edit_solid2, 'String') );
options.postprocessing.solidThresh = [solidThresh1 solidThresh2];

options.refine.cluster.dt.T = str2double(get(handles.edit_clusterT, 'String'));
options.refine.cluster.max_recurr = str2double(get(handles.edit_maxrecur, 'String'));



function myLayer = choose_layer (options)
options_num = options.hsv + options.bratio + options.brown + options.deconv_DAB + options.deconv_H;
if options_num > 1
    disp('Error. More than one layer selected.');
    myLayer = 'HS(V)'; % default value
    return;
end
%list_layer = {'(R)GB','HS(V)','H - color deconv.','DAB - color deconv.','Blue ratio', 'Brown'};
if options.hsv
    myLayer = 'HS(V)';

elseif options.bratio
    myLayer = 'Blue ratio';

elseif options.brown
    myLayer = 'Brown';

elseif options.deconv_H
    myLayer = 'H - color deconv.';

elseif options.deconv_DAB
    myLayer = 'DAB - color deconv.';

elseif options.red
    myLayer = '(R)GB';
    
else
    myLayer = 'HS(V)';
end


function myDataset = choose_dataset (handles)
list_data = get(handles.pop_data, 'String');
idx = get(handles.pop_data, 'Value');
myDataset = list_data{idx};
