function myI = lr_choose_layer (I, options)

% if size(I,3) ~= 3
%     disp('Error. No third channel, whole image needed.');
%     myI=I;
% end

options_num = options.hsv + options.bratio + options.brown + options.deconv_DAB + options.deconv_H;

if options_num > 1
    warning('Error. More than one layer selected.');
    myI=[];
    return;
end


if options.hsv
    I_hsv=rgb2hsv(I);
    myI=I_hsv(:,:,3);

elseif options.bratio
    R = I(:,:,1);
    G = I(:,:,2);
    B = I(:,:,3);
    part1 = (100*B) ./ (1+R+G);
    part2 = 256 ./ (1+B+R+G);
    I_bratio= part1 .* part2;
    myI=I_bratio;

elseif options.brown
    R = I(:,:,1);
    G = I(:,:,2);
    B = I(:,:,3);
    I_brown = B - (0.3 * (R+G));
    myI=I_brown;

elseif options.deconv_H
    [I_deconv_H] = colourDeconv(I);
    myI=double(I_deconv_H);

elseif options.deconv_DAB
    [I_deconv_H, I_deconv_DAB] = colourDeconv(I);
    myI=double(I_deconv_DAB);

elseif options.red
    try 
        myI=I(:,:,1);
    catch ME
        disp(['Error:',ME.message]);
        myI=I;
    end
    
else
    try 
        myI=I(:,:,3);
    catch ME
        disp(['Error:',ME.message]);
        disp('Error. No third channel, whole image needed.');
        myI=I;
    end
end
