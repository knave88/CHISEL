function new_res_img_crop_out = my_roi_mask (roi_cell, img2_size, pad_filter_size)

opt_show = false;
%pad_filter_size = 10;

for i = 1:length(roi_cell)
    if ~isempty(roi_cell{i})
        new_roi_cell{i}(1) = roi_cell{i}(1) + pad_filter_size;
        new_roi_cell{i}(2) = roi_cell{i}(2) + pad_filter_size;
        new_roi_cell{i}(3) = roi_cell{i}(3) - 2*pad_filter_size;
        new_roi_cell{i}(4) = roi_cell{i}(4) - 2*pad_filter_size;
    end
end

new_roi_cell = new_roi_cell';

if opt_show == true
    for i = 1: length(new_roi_cell)
        if ~isempty(new_roi_cell{i})
            imrect(gca, new_roi_cell{i});
            %pause(0.5);
        end
    end
    disp('fin!')
end

new_res_img = zeros(img2_size);
for i = 1:length(new_roi_cell)
    if ~isempty(new_roi_cell{i})
        %temp_img1 = imcrop(img,new_roi_cell{i});
        temp_img2 = ones(size(new_roi_cell{i}(4), new_roi_cell{i}(2)));
        new_res_img(new_roi_cell{i}(2):new_roi_cell{i}(2)+new_roi_cell{i}(4), new_roi_cell{i}(1):new_roi_cell{i}(1)+new_roi_cell{i}(3)) = temp_img2;
        
    end
end
new_res_img_crop = imcrop(new_res_img, [1,1,img2_size(2)-1,img2_size(1)-1]);

%figure; imagesc(new_res_img_crop);

new_res_img_crop_out = imcomplement(new_res_img_crop);