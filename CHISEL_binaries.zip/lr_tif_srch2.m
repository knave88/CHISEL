function files_out = lr_tif_srch2 (f_dir)


%options.main.selection = 'file';


switch f_dir
    case 'current_folder'
my_files=dir;

    case 'select_folder'
my_files = dir(uigetdir);
    case 'file'
        [FileName,PathName] = uigetfile('*.tif','Select the file');
        my_file = [PathName,FileName];
end

if strcmp(f_dir,'file')
    if regexpi(my_file, '.tif') %~isempty(strfind(my_file, '.tif'))
        files_out{1} = my_file;
    else
        files_out = cell(0);
    end
    return;
end
    
found = [];
for i=1:length(my_files)
    if regexpi(my_files(i).name, '.tif') %~isempty(strfind(my_files(i).name , '.tif'))
        found=[found, i];
    end
end

files_out = cell(0);
for j=1:length(found)
    files_out{j} = my_files(found(j)).name;
end

end % lr_tif_srch