function [out_img, out_obj]= p7_post_gpu (I_in_bw, main_opt)


% optional cutting border
if (main_opt.border.value >0 && isempty(strfind(file_name, '_cutBorder')))
    [I_in_bw, file_name] = lr_cutBorder1 (I_in_bw, main_opt.border, file_name);
end


try
% identify objects
bw_labeled = bwlabel(~I_in_bw);
bw_label_flag = true; %inverted

if max(max( bw_labeled )) == 1
    bw_labeled = bwlabel(I_in_bw);
    bw_label_flag = false; %normal
end

if max(max( bw_labeled )) == 0
    out_img=[];
    out_obj = [];
    return
end


catch ME
    if main_opt.printError == true
        if strcmp(ME.message, 'Function BWLABEL expected its first input, BW, to be two-dimensional.')
            disp(sprintf('Image; %s; is not valid BW image.',file_name));
        else
            disp(ME.message)
        end
    end
    out_img=[];
    out_obj = [];
    return
end

% find objects
my_obj_found_noInv = lr_find_objects (bw_labeled, main_opt);

if main_opt.inverseFinding
    if bw_label_flag
        my_obj_found_inv = lr_find_objects (bwlabel(I_in_bw), main_opt);
    else
        my_obj_found_inv = lr_find_objects (bwlabel(~I_in_bw), main_opt);
    end
    my_obj_found = vertcat(my_obj_found_noInv, my_obj_found_inv);
end


if length(my_obj_found_noInv) > length(my_obj_found_inv)
    my_obj_found = my_obj_found_noInv;
else
    my_obj_found =  my_obj_found_inv;
end

% image from object list
img_obj = crt_obj (my_obj_found, size(I_in_bw));


%out.method = lr_find_method_inStr (file_name);


% save results
% if main_opt.saveOut
%     new_file_name = [file_name(1:length(file_name)-4),'_post' ,'.tif'];
%     imwrite(img_obj,new_file_name);
% end

%out.toDisp = sprintf('Image; %s; Objects after selection; %d; Size threshold; %d',file_name, length(my_obj_found), main_opt.T_size);
%if main_opt.presentOut == true
%    disp(out.toDisp);
%end

%out.file = file_name;
out_img = img_obj;
out_obj = my_obj_found;
%out.plotellipse = 'plot(c(1) + af(1)*cos(t), c(2) + af(2)*sin(t)) where t=0:pi/100:2*pi;';

end % main function


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
function im_out = crt_obj (obj_in, im_size)

im_out = zeros(im_size, 'gpuArray');
for i=1:length(obj_in);
    for j=1:length(obj_in(i).PixelList)
        im_out(obj_in(i).PixelList(j,2), obj_in(i).PixelList(j,1)) = 1;
    end
end
end % crt_obj


function my_obj_found = lr_find_objects (bw_labeled, main_opt)

% count objects
obj_num = max(max( bw_labeled ));

% find objects
%--------------------------------------------------------------------------
% statistical data
my_obj_found  = regionprops(bw_labeled, 'Centroid', 'Area', 'PixelList');
%my_obj_found  = regionprops(bw_labeled, 'basic');


%--------------------------------------------------------------------------
%discrimination
obj_to_del = [];

% test for object size

if main_opt.discrimination_size
    T_size = main_opt.T_size;
    for i=1:obj_num
        %if my_obj_found(i).Area <= T_size(1) || my_obj_found(i).Area >= T_size(2)  % T_size in px
        if my_obj_found(i).Area <= T_size(1) %|| my_obj_found(i).Area >= T_size(2)  % T_size in px  % #mod 15.06.2018
            obj_to_del=[obj_to_del,i];
        end
    end
end


%--------------------------------------------------------------------------
% discrimination of objects on border
[border_h border_w] = size(bw_labeled);
if main_opt.discrimination_border
    for i=1:obj_num
        if ~isempty(find(my_obj_found(i).PixelList == 1, 1)) || ~isempty(find(my_obj_found(i).PixelList == border_h, 1)) || ~isempty(find(my_obj_found(i).PixelList == border_w, 1))
            obj_to_del=[obj_to_del,i];
        end
    end
end

%--------------------------------------------------------------------------
% delete discriminated objects
try
    obj_to_del = sort(unique(obj_to_del),'descend');
    my_obj_found(obj_to_del) = [];
catch ME
    disp(ME.message)
end

end % lr_find_objects