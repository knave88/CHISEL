function out = process_img_byROI (in, roi_cell, roi_pad)
% #TODO a lot TODO !!!!!!!!!!!!

out = zeros(size(in));


options.bradley.params.method = 'bradley';
options.bradley.params.window = [151 151];
options.bradley.params.T = 5;
options.bradley.params.padding = 'replicate';

for k = 1:length(roi_cell)
    if ~isempty(roi_cell{k})
        tmp_in = imcrop(in, roi_cell{k});
        tmp_out = lr_tresh_bradley1(tmp_in, options.bradley.params.window, options.bradley.params.T, options.bradley.params.padding);

        try
            out( roi_cell{k}(2):roi_cell{k}(2)+size(tmp_out,1)-1,  roi_cell{k}(1):roi_cell{k}(1)+size(tmp_out,2)-1 ) = tmp_out; % #TODO !temporary solution! do poprawy
        catch ME
            disp(['!!! ERROR !!! ___  ', ME.message]);
        end
    end
end

%figure;imagesc(out);

%out = lr_tresh_bradley1(in, options.bradley.params.window, options.bradley.params.T, options.bradley.params.padding);
%out = in;