function out = P7_test1 (options)
%P7_test1
%last edited: 04.04.2019
%files needed:
%
%

out=[];

warning('off')

%% search for files
files_out = lr_tif_srch2 (options.main.selection);

%% segmentation
if options.main.roi_process
    for k=1:length(files_out)
        
        myinfo = imfinfo(files_out{k});
        
        if myinfo.SamplesPerPixel == 3
        
            %out_temp{k} = my_roi_split_v2 (files_out{k}, options.roi.roi_size, options.roi.pad_filter_size, options);
            out_temp{k} = P7_process_image (files_out{k}, options);
            figure;imagesc(out_temp{k});
            drawnow;

            
            
        end
        
    end
end   

out = out_temp;