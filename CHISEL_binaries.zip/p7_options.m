% p7 options

function options = p7_options()
%choose one layer:
options.segmentation.layer.bratio = false;
options.segmentation.layer.brown = false;
options.segmentation.layer.deconv_DAB = false;
options.segmentation.layer.deconv_H = false;
options.segmentation.layer.hsv = true;
options.segmentation.layer.red = false;

%roi options:
options.roi.roi_size = 1000; 
options.roi.pad_filter_size = 151;

options.roi.select = true; 
options.roi.parallel = true;
options.roi.gpu = true;

options.segmentation.cut = 0;
options.segmentation.c_val = [10];
border_value = 0; % postprocessing optional border cut

options.segmentation.bradley.params.method = 'bradley';
options.segmentation.bradley.params.window = [151 151];
options.segmentation.bradley.params.T = 5;
options.segmentation.bradley.params.padding = 'replicate';


options.postprocessing.discrimination_size = true;
options.postprocessing.discrimination_border = false;
options.postprocessing.discrimination_roundness = false;
options.postprocessing.discrimination_solidity = false;

options.postprocessing.presentObj = false;
options.postprocessing.calculateEdge = false; % wykuczenie Optimization_Toolbox z uwagi na ograniczone licencje
options.postprocessing.presentEdge = false;
options.postprocessing.presentRoundness = false;
options.postprocessing.presentOut = false;
options.postprocessing.saveOut = true;
options.postprocessing.printError = false;
options.postprocessing.T_size = [50 10000]; % [50 10000];

options.postprocessing.border.save = false;
options.postprocessing.border.value = border_value;

options.postprocessing.inverseFinding = true;
options.postprocessing.solidThresh = [0.4 Inf];
options.postprocessing.roundThresh = [-Inf Inf];


options.refine.only_postprocessed = true;
options.refine.refine_method = 11; %(11)    0 1 11 2 22 3 4 5 6 8 (0 = just filling holes)
options.refine.show = false;
options.refine.show_out = false;
options.refine.save = true;
options.refine.expand = 0;
options.refine.refine_size_thresh = 20; %25


% refine_method 1
options.refine.ms.params.rad = 11; % 51
options.refine.ms.params.alpha = 0.003; %def 0.03 % coefficient of the length term
options.refine.ms.params.num_it = 20; %def 100
options.refine.ms.params.epsilon = 0.02; % def 1

% refine_method 2
options.refine.um.params.rad = 51;
options.refine.um.params.alpha = 0.03; % coefficient of the length term
options.refine.um.params.num_it = 100;
options.refine.um.params.epsilon = 1;

% refine_method 3
%options.refine.cv.params.mask_init = 'medium'; % small medium large whole whole+small
options.refine.cv.params.num_iter = 20; % def 1000
options.refine.cv.params.mu = 0.2; %def 0.2 % weight of length term
options.refine.cv.params.method = 'chan'; %('chan','vector','multiphase')

% cluster splitting
options.refine.cluster.when = 'before'; % before after after2 none middle
options.refine.cluster.method = 'DT'; % waterSeeded, DT, Hminima, huang, mouelhi, kong, none (method = none turns off splitting)
options.refine.cluster.show = false;

options.refine.cluster.dataset = 'IISPV'; % BBBC004 / IISPV
options.refine.cluster.max_recurr = 7; % IISPV (7) / BBBC004 (30)

options.refine.cluster.kong.do = true;
options.refine.cluster.kong.visualize1 = false;
options.refine.cluster.kong.visualize2 = false;
options.refine.cluster.kong.visualize3 = false;

options.refine.cluster.mouelhi.T_min_ridge_length = 3;
options.refine.cluster.mouelhi.T_eucDist = 15;
options.refine.cluster.mouelhi.visualize1 = false;
options.refine.cluster.mouelhi.visualize2 = false;

options.refine.cluster.waterseeded.visualize1 = false;
options.refine.cluster.waterseeded.gradientOnBW = true;

options.refine.cluster.dt.visualize1 = false;
options.refine.cluster.dt.T = 0.55; % 0.6
options.refine.cluster.dt.gradientOnBW = true;

options.refine.cluster.hminima.visualize1 = false;
options.refine.cluster.hminima.T = 0.8;
options.refine.cluster.hminima.gradientOnBW = true;

options.refine.cluster.huang.visualize1 = false;
options.refine.cluster.huang.gradientOnBW = true;
%options.refine.cluster.huang

