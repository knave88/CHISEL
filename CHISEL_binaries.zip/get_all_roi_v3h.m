function [roi_cell, roi_pad] = get_all_roi_v3h (img_size, roi_size, roi_shift)

m = img_size(1);
n = img_size(2);

opt_show = false;

if roi_shift >= roi_size
    roi_cell = [];
    roi_pad = [];
    disp('Error: roi_shift should not be greater than roi_size');
    return
end

idx_out = 1;

%[m, n] = size(img);

m_next = 1:roi_size:m;
n_next = 1:roi_size:n;

if roi_shift > 0 
    roi_cell = cell((length(m_next)*length(n_next)) + length(m_next) + length(n_next) + 1 , 1);
    roi_pad = cell((length(m_next)*length(n_next)) + length(m_next) + length(n_next) + 1 , 1);
else
    roi_cell = cell(length(m_next)*length(n_next),1);
    roi_pad = cell(length(m_next)*length(n_next),1);
end

% if opt_show == true
%     figure; imagesc(img);
% end


% all non padded roi

for k1 = 1: length(m_next)
    for k2 = 1: length(n_next)

        my_roi = [n_next(k2)+roi_shift ,m_next(k1), roi_size, roi_size];
        
        if opt_show == true
            imrect(gca, my_roi);
        end
        
        if checkInside (my_roi, m, n)
            roi_cell{idx_out} = my_roi;
            roi_pad{idx_out} = NaN;
            idx_out = idx_out+1;
        end
        
        
    end
end

% first column
for k = 2 : length(n_next)
    my_roi = [1, n_next(k), roi_shift, roi_size];
    
    if opt_show == true
        imrect(gca, my_roi);
    end

    if checkInside (my_roi, m, n)
        roi_cell{idx_out} = my_roi;
        roi_pad{idx_out} = NaN;
        idx_out = idx_out+1;
    end
end

% remaining corners roi
if roi_shift > 0 
    my_roi = [1, 1, roi_shift, roi_size];
    roi_cell{idx_out} = my_roi;
    roi_pad{idx_out} = 'tl'; % image in bottom right of roi
    idx_out = idx_out+1;
    
    my_roi = [n_next(length(n_next))+roi_shift, 1, n-1-n_next(length(n_next))-roi_shift, roi_shift];
    if checkInside (my_roi, m, n)
        roi_cell{idx_out} = my_roi;
        roi_pad{idx_out} = 'tr'; % image should be in bottom left corner of padded roi
        idx_out = idx_out+1;
    end
    
    my_roi = [1, m_next(length(m_next))+roi_shift, roi_shift, m-1-m_next(length(m_next))-roi_shift];
    if checkInside (my_roi, m, n) 
        roi_cell{idx_out} = my_roi;
        roi_pad{idx_out} = 'bl'; % image should be in top right corner of padded roi
        idx_out = idx_out+1;
    end
    
end

% last corner
my_roi = [n_next(length(n_next))+roi_shift, m_next(length(m_next))+roi_shift, n-n_next(length(n_next)), m-m_next(length(m_next))];
if checkInside (my_roi, m, n)
    roi_cell{idx_out} = my_roi;
    roi_pad{idx_out} = 'br'; % image should be in top left corner of padded roi
end

%out = out';


function out = checkInside (my_roi, m, n)
out = false;
if my_roi(1) <= n && my_roi(2) <= m && my_roi(1) >= 1 && my_roi(2) >= 1
    out = true;
end

function out = checkInside2 (my_roi, m, n)
out = false;
if my_roi(1) <= n && my_roi(2) <= m && my_roi(1) >= 1 && my_roi(2) >= 1 ...
    && my_roi(1)+my_roi(3) <=n && my_roi(2)+my_roi(4) <=m 
    out = true;
end