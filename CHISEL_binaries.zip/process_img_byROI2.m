function I_out = process_img_byROI2 (filename, roi_cell, roi_pad, options)
% #TODO a lot TODO !!!!!!!!!!!!


if ~isempty(strfind(filename, '_post')) || ~isempty(strfind(filename, '_BW')) || ~isempty(strfind(filename, '_SCORE'))
    I_out=[];
    return
end 

file_info = imfinfo(filename);
img2_size = [file_info.Width, file_info.Height];

[userview,systemview] = memory;

if userview.MaxPossibleArrayBytes < 1.2*file_info.FileSize
    %load roi by roi into memory
    I_out = proc_image_block(filename, roi_cell, roi_pad, options);
else
    %load hole image into memory
    I_out = proc_image_whole(filename, roi_cell, roi_pad, options);
end



%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

function I_out = proc_image_whole(filename, roi_cell, roi_pad, options)

I=imread(filename);
%convert to double
I=double(I);

%% border cut

if options.segmentation.cut ~= 0
    tmp_cut=options.segmentation.cut;
    I=I(1:tmp_cut,1:tmp_cut,:);
end

%% layer options

myI = lr_choose_layer (I, options.segmentation.layer);
if isempty(myI)
    I_out=[];
    return;
end


%% proc...
for k = 1:length(roi_cell)
    if ~isempty(roi_cell{k})
        tmp_in = imcrop(myI, roi_cell{k});
        tmp_out = proc_one_roi (tmp_in, options);

        try
            I_out( roi_cell{k}(2):roi_cell{k}(2)+size(tmp_out,1)-1,  roi_cell{k}(1):roi_cell{k}(1)+size(tmp_out,2)-1 ) = tmp_out; % #TODO !temporary solution! do poprawy
        catch ME
            disp(['!!! ERROR !!! ___  ', ME.message]);
        end
    end
end

%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

function I_out = proc_image_block(filename, roi_cell, roi_pad, options)

[pathstr,name,ext] = fileparts(filename) ;
file_info = imfinfo(filename);
img_size = [file_info.Width, file_info.Height];
userview = memory;

temp_block_size = floor(sqrt(userview.MaxPossibleArrayBytes) / 9);


fun = @(block_struct) (block_one_roi(block_struct.data));
blockproc(filename,[temp_block_size temp_block_size],fun, 'Destination','New.tif');

%------------------------------------------
[pathstr,name,ext] = fileparts(filename) ;

switch lower(ext)
    case {'.tif','.tiff','.jpg','.jpeg'}
        for k = 1:length(roi_cell)
            if ~isempty(roi_cell{k})
                myRegion = boundingBox2pixelRegion (roi_cell{k});
                tmp_in=imread(filename, 'PixelRegion',myRegion);
                
                tmp_out = proc_one_roi (tmp_in, options);
            end
        end
        
    otherwise
        I_out = [];
end

function myRegion = boundingBox2pixelRegion (myRoi)
myRegion = zeros(size(myRoi));
if size(myRoi) == [1, 4]
    myRegion = {[myRoi(2), myRoi(2)+myRoi(4)], [myRoi(1),  myRoi(1)+myRoi(3)]};
end



