function img_out = P7_nn_classify (I_rgb, I_mask, options)

load net_ver_test1.mat

if isempty(I_rgb) || isempty(I_mask)
    img_out = [];
end

if options.segmentation.layer.hsv == 1
    layer_opt = 'hsv';
else
    layer_opt = 'rgb';
end

feat_opt = 'all';

    % #TODO: rgb2gray, colorDeconv, HSV...
    if strcmpi(layer_opt, 'rgb')
        [FEAT_vector1, s_feat] = calc_feat_ver2 (I_rgb(:,:,1), I_mask, feat_opt);
        FEAT_vector2 = calc_feat_ver2 (I_rgb(:,:,2), I_mask, feat_opt);
        FEAT_vector3 = calc_feat_ver2 (I_rgb(:,:,3), I_mask, feat_opt);
        FEAT_vector = vertcat(FEAT_vector1,FEAT_vector2,FEAT_vector3);
    elseif strcmpi(layer_opt, 'hsv')
        I_hsv=rgb2hsv(I_rgb);
        [FEAT_vector1, s_feat] = calc_feat_ver2 (I_hsv(:,:,1), I_mask, feat_opt);
        FEAT_vector2 = calc_feat_ver2 (I_hsv(:,:,2), I_mask, feat_opt);
        FEAT_vector3 = calc_feat_ver2 (I_hsv(:,:,3), I_mask, feat_opt);
        
        %FEAT_vector = vertcat(FEAT_vector1,FEAT_vector2,FEAT_vector3);
        FEAT_vector = FEAT_vector3;
    else
        I_conv = select_layer (I_rgb, layer_opt);
        [FEAT_vector, s_feat] = calc_feat_ver2 (I_conv, I_mask, feat_opt);
    end
    
%    out = horzcat(out,FEAT_vector);
    

    
x =FEAT_vector;
y = net(x);
yind = vec2ind(y);

img_out = zeros(size(I_mask));
for k_obj = 1:length(s_feat)
    img_out(s_feat(k_obj).PixelIdxList) = yind(k_obj);
end

%figure;
%imagesc(img_out);