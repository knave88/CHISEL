function [I_out,I_out_roi] = proc_image_whole(filename, options)

I=imread(filename);
%convert to double
I=double(I);

%% border cut

if options.segmentation.cut ~= 0
    tmp_cut=options.segmentation.cut;
    I=I(1:tmp_cut,1:tmp_cut,:);
end

%% layer options

myI = lr_choose_layer (I, options.segmentation.layer);
if isempty(myI)
    I_out=[];
    return;
end


%% proc...
I_out = P7_process_withROI (myI, options);

I_out_roi = I_out;


%% classify objects
I_bw_temp = logical(I_out>0);
I_out = P7_nn_classify (I, I_bw_temp, options);



%% save results % TODO