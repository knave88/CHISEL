function [files_out, BW_files, marker_files] = lr_tif_srch3 (f_dir)


%options.main.selection = 'file';


switch f_dir
    case 'current_folder'
my_files=dir;

    case 'select_folder'
my_files = dir(uigetdir);
    case 'file'
        [FileName,PathName] = uigetfile('*.tif','Select the file');
        my_file = [PathName,FileName];
end

if strcmp(f_dir,'file')
    if regexpi(my_file, '.tif') %~isempty(strfind(my_file, '.tif'))
        files_out{1} = my_file;
    else
        files_out = cell(0);
    end
    return;
end
    
found = [];
for i=1:length(my_files)
    if regexpi(my_files(i).name, '.tif') %~isempty(strfind(my_files(i).name , '.tif'))
        found=[found, i];
    end
end

files_out = cell(0);
for j=1:length(found)
    files_out{j} = my_files(found(j)).name;
end

BW_files = dir_BW_files (files_out);

marker_files = dir_marker_files (files_out);

end % lr_tif_srch


function BW_files = dir_BW_files (files_out)
% find file with BW map
BW_file = find(~(cellfun(@isempty,strfind(files_out,'_BW'))));

BW_files = files_out(BW_file);

end % dir_BW_files


function marker_files = dir_marker_files (files_out)
% find file with BW map
marker_file = find(~(cellfun(@isempty,strfind(files_out,'_SCORE'))));

marker_files = files_out(marker_file);

end % dir_marker_files

