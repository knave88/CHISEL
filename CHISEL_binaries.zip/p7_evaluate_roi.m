function out = p7_evaluate_roi (img)

if isempty(img)
    out = [];
end

FEAT_vector = LR_get_roi_features_forP7(img);

load('net_roi.mat', 'net');


y = net(FEAT_vector);
out = vec2ind(y)-1;

%out = 0 : ROI to evaluate
%out = 1 : ROI to omit