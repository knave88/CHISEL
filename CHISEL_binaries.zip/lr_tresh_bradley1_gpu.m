function out = lr_tresh_bradley1_gpu(in, window, T, padding)
%def param: [15 15], 10, 'replicate'


%BRADLEY local thresholding.
%   BW = BRADLEY(IMAGE) performs local thresholding of a two-dimensional
%   array IMAGE with Bradley method. The key idea of the algorithm is that
%   every image's pixel is set to black if its brightness is T percent
%   lower than the average brightness of surrounding pixels in the window
%   of the specified size, otherwise it is set to white.
%      
%   BW = BRADLEY(IMAGE, [M N], T, PADDING) performs local
%   thresholding with M-by-N neighbourhood (default is 15-by-15). The 
%   default value for T is 10 and can be set in range 0..100. To deal with 
%   border pixels the image is padded with one of PADARRAY options (default 
%   is 'replicate').
%       
%   Example
%   -------
%       imshow(bradley(imread('eight.tif'), [125 125], 10));
%
%   See also PADARRAY, RGB2GRRAY.

%   Contributed by Jan Motl (jan@motl.us)
%   $Revision: 1.1 $  $Date: 2015/04/19 17:03:01 $
if ndims(in) ~= 2
    error('The input image must be a two-dimensional array.');
end

% Convert to double
in = double(in);

% Local mean
mean = averagefilter_gpu(in, window, padding);

% Initialize the output to white color
out = true(size(in), 'gpuArray');

% Set a pixel to black if the image brightness 
% is below (100-T)% of the average neighbourhood brightness
out(in <= mean*(1-T/100)) = 0;
