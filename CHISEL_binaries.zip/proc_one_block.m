function out = proc_one_block (I, options)

%options = p7_options;

try

%convert to double
I=double(I);

%% classify ROI (omit/process)
if options.roi.select
    try
        roi_eval = p7_evaluate_roi (I);
        if roi_eval == 2
            out = zeros(size(I));
            return;
        end
    catch ME
        disp(['Error',ME.message]);
    end
end
%% layer options

myI = lr_choose_layer (I, options.segmentation.layer);
if isempty(myI)
    out=[];
    return;
end


if options.roi.gpu
    out = proc_one_roi_gpu (myI, options);
else
    out = proc_one_roi (myI, options);
end

%% classify objects
I_bw_temp = logical(out);
I_out = P7_nn_classify (I, I_bw_temp, options);
out = uint8(I_out);

if isempty(out)
    out =uint8( zeros(size(myI)));
end

catch ME_main
    disp(['Error:: ',ME_main.message]);
    out = uint8(zeros(size(myI)));
    return;
end