function out = feat_geo (bw_img)

out = regionprops(bw_img, 'Area', 'MajorAxisLength', 'MinorAxisLength', 'Eccentricity', 'Orientation', 'FilledArea', 'EulerNumber', 'EquivDiameter', 'Solidity', 'Extent', 'Perimeter');

%Area, MajorAxisLength, MinorAxisLength, Eccentricity, Orientation, FilledArea, EulerNumber, EquivDiameter, Solidity, Extent, Perimeter
