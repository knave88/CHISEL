function out = HaarWavEnFeat (img)

% Haar wavelet energy feature extraction 
% Feature is computed at 5 scales within four frequency bands LL, LH, HL and HH.

% There exist three types of detail images for each
% resolution: horizontal (HL), vertical (LH), and diagonal (HH).
% The operations can be repeated on the low low (LL) band
% using the second stage of identical filter bank.

%[a,h,v,d] = hlwt2(img,false);
max_scales = 5;
tmp_img = img;

% calculate Haar wavelet coefficients
for k = 1:max_scales
    [tmp_img, HL{k}, LH{k}, HH{k}] = hlwt2(tmp_img,false);
    LL{k} = tmp_img;

end

for k = 1:max_scales
    %tmp_energy = sum(sum((LL{k}).^2));
    eval(['out.WavEnLL_',num2str(k),'= sum(sum((LL{k}).^2));']);
    eval(['out.WavEnHL_',num2str(k),'= sum(sum((HL{k}).^2));']);
    eval(['out.WavEnLH_',num2str(k),'= sum(sum((LH{k}).^2));']);
    eval(['out.WavEnHH_',num2str(k),'= sum(sum((HH{k}).^2));']);
end

%disp(1);


function [a,h,v,d] = hlwt2(x,integerflag)
%HLWT2 Haar (Integer) Wavelet decomposition 2-D using lifting.
%	HLWT2 performs the 2-D lifting Haar wavelet decomposition.
%
%   [CA,CH,CV,CD] = HLWT2(X) computes the approximation
%   coefficients matrix CA and detail coefficients matrices
%   CH, CV and CD obtained by the haar lifting wavelet 
%   decomposition, of the matrix X.
%
%   [CA,CH,CV,CD] = HLWT2(X,INTFLAG) returns integer coefficients.
 
% Test for odd input.
s = size(x);
odd_Col = rem(s(2),2);
if odd_Col , x(:,end+1,:) = x(:,end,:); end
odd_Row = rem(s(1),2);
if odd_Row , x(end+1,:,:) = x(end,:,:); end

% Splitting.
L = x(:,1:2:end,:);
H = x(:,2:2:end,:);

% Lifting.
H = H-L;        % Dual lifting.
if ~integerflag
    L = (L+H/2);      % Primal lifting.
else
    L = (L+fix(H/2)); % Primal lifting.
end

% Splitting.
a = L(1:2:end,:,:);
h = L(2:2:end,:,:);


% Lifting.
h = h-a;        % Dual lifting.
if ~integerflag
    
    a = (a+h/2);      % Primal lifting.
    a = 2*a;
else
    a = (a+fix(h/2)); % Primal lifting.
end

% Splitting.
v = H(1:2:end,:,:);
d = H(2:2:end,:,:);

% Lifting.
d = d-v;         % Dual lifting.
if ~integerflag
    v = (v+d/2); % Primal lifting.
    % Normalization.
    d = d/2;
else
    v = (v+fix(d/2)); % Primal lifting.
end

if odd_Col ,  v(:,end,:) = []; d(:,end,:) = []; end
if odd_Row ,  h(end,:,:) = []; d(end,:,:) = [];  end

function params = parseinputs(x,varargin)
params.lev = [];
validateattributes(x,{'numeric'},{'3d','real','finite','nonempty'},...
    'haart2','X',1);

if (ndims(x) == 3 && size(x,3) ~= 3) || ndims(x) == 1
    error(message('Wavelet:FunctionInput:InvalidMatrixInput'));
end

Ny = size(x,1);
Nx = size(x,2);
if rem(Nx,2) || rem(Ny,2)
    error(message('Wavelet:FunctionInput:InvalidRowOrColSize'));
end

N = min([Ny Nx]);
if ~rem(log2(N),1)
    params.maxlev = log2(N);
else
    params.maxlev = floor(log2(N/2));

end

if any(cellfun(@ischar,varargin))
    error(message('Wavelet:FunctionInput:UnrecognizedString'));
end

if isempty(varargin)
    return;
else
    tf = find(cellfun(@isnumeric,varargin));
end

if nnz(tf) == 1
    params.lev = varargin{tf>0};
    validateattributes(params.lev,{'numeric'},{'integer','scalar','>=',1,...
        '<=',params.maxlev},'haart2','LEVEL');
   
end
