function out_bw = my_roi_split_v2 (img2, roi_size, pad_filter_size, options)
% #TODO merging with voting (% udzial bazy i skladowych obrazow)
out_bw = [];

info = imfinfo(img2);
img2_size = [info.Width, info.Height];

%base roi split
[roi_cell1, roi_pad1] = get_all_roi_v3 (img2_size, roi_size, 0);

%process base image with roi by roi method
base_result_img = process_img_byROI2 (img2, roi_cell1, roi_pad1, options); % #TODO

%get binary mask of overlapping
bw1 = logical( my_roi_mask (roi_cell1, img2_size, pad_filter_size) );

%results shifted by padding 
[roi_cell2a, roi_pad2a] = get_all_roi_v3h (img2_size, roi_size, pad_filter_size);
[roi_cell2b, roi_pad2b] = get_all_roi_v3v (img2_size, roi_size, pad_filter_size);
%process image
result_img2a = process_img_byROI2 (img2, roi_cell2a, roi_pad2a, options);
result_img2b = process_img_byROI2 (img2, roi_cell2b, roi_pad2b, options);

%use binary maps to know where to merge results
bw2a = logical( my_roi_mask (roi_cell2a, img2_size, pad_filter_size) );
bw2b = logical( my_roi_mask (roi_cell2b, img2_size, pad_filter_size) );

result_img2a_2merge = ~result_img2a .* bw2a;
result_img2b_2merge = ~result_img2b .* bw2b;

%out = logical(base_result_img) | logical(result_img2a_2merge) | logical(result_img2b_2merge);

%out_bw = ~base_result_img + result_img2a_2merge .* result_img2b_2merge;

%results shifted (other sides)
[roi_cell3a, roi_pad3a] = get_all_roi_v3h (img2_size, roi_size, (roi_size-pad_filter_size) );
[roi_cell3b, roi_pad3b] = get_all_roi_v3v (img2_size, roi_size, (roi_size-pad_filter_size) );

%process image
result_img3a = process_img_byROI2 (img2, roi_cell3a, roi_pad3a, options);
result_img3b = process_img_byROI2 (img2, roi_cell3b, roi_pad3b, options);


bw3a = my_roi_mask (roi_cell3a, img2_size, pad_filter_size);
bw3a = logical(bw3a);

bw3b = my_roi_mask (roi_cell3b, img2_size, pad_filter_size);
bw3b = logical(bw3b);

try
result_img3a_2merge = ~result_img3a .* bw3a;
result_img3b_2merge = ~result_img3b .* bw3b;
catch ME
    ME.message
end

out_bw = ~base_result_img + result_img2a_2merge + result_img2b_2merge + result_img3a_2merge + result_img3b_2merge;

%final output
%out_bw = ((bw1 & bw2a) | (bw1 & bw2b)) | ((bw1 & bw3a) | (bw1 & bw3b));
%figure;imagesc(temp_bw);

tmp_img = ~result_img2a_2merge + ~result_img2b_2merge + ~result_img3a_2merge + ~result_img3b_2merge;
figure;
subplot(2,3,1);imagesc(base_result_img);title('base');
subplot(2,3,4);imagesc(tmp_img);title('out');

subplot(2,3,2);imagesc(result_img2a_2merge);title('img 2a');
subplot(2,3,5);imagesc(result_img2b_2merge);title('img 2b');

subplot(2,3,3);imagesc(result_img3a_2merge);title('img 3a');
subplot(2,3,6);imagesc(result_img3b_2merge);title('img 3b');

% tmp_img2 = (bw1&~result_img2a_2merge) + (bw1&~result_img2b_2merge) + (bw1&~result_img3a_2merge) + (bw1&~result_img3b_2merge);
% tmp_out_bw2 = logical(base_result_img) & logical(tmp_img2);
% 
% tmp_img3 = (~result_img2a_2merge) & (~result_img2b_2merge) & (~result_img3a_2merge) & (~result_img3b_2merge);
% tmp_out_bw3 = logical(base_result_img) & logical(tmp_img3);
