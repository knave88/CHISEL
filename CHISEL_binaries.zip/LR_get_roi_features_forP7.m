function FEAT_vector = LR_get_roi_features_forP7(img)
%collect features from image
%needs Region Of Interest

% FEAT_vector1 = calc_feat (img(:,:,1));
% FEAT_vector2 = calc_feat (img(:,:,2));
% FEAT_vector3 = calc_feat (img(:,:,3));
% FEAT_vector = vertcat(FEAT_vector1,FEAT_vector2,FEAT_vector3);

layer_opt = 'v'; 
I_conv = select_layer (img, layer_opt);
FEAT_vector = calc_feat (I_conv);





function myI = select_layer (I, layer_opt)
%select one layer: 'bratio', 'dab', 'v'

switch layer_opt
    case 'bratio' % (blue-ratio)
        R = I(:,:,1);
        G = I(:,:,2);
        B = I(:,:,3);
        part1 = (100*B) ./ (1+R+G);
        part2 = 256 ./ (1+B+R+G);
        myI= part1 .* part2;
        
    case 'dab' %(color deconvolution)
        [I_deconv_H, I_deconv_DAB] = colourDeconv(I);
        myI=double(I_deconv_DAB);
        
    case 'v' %(HSV)
        I_hsv=rgb2hsv(I);
        myI=I_hsv(:,:,3);
        
    case 'rgb_b'
        myI = I(:,:,3);
    case 'rgb_g'
        myI = I(:,:,2);
    case 'rgb_r'
        myI = I(:,:,1);
        
    otherwise
        myI = [];

end


function FEAT_vector = calc_feat(current_obj_img)

% calculate features
    
    features_glrlm = feat_glrlm (current_obj_img);
    
    features_grad = feat_grad (current_obj_img);
    
    features_hist = feat_hist (current_obj_img);
    
    features_haar = HaarWavEnFeat (current_obj_img);
    
    features_ar = feat_ar_new(current_obj_img);
    
    
    
    %vectorization
    
    features_hog_vec = HOG(current_obj_img);
    % #9
    
    features_hist_vec = cell2mat(struct2cell(features_hist));
    % #9
    
    features_grad_vec = cell2mat(struct2cell(features_grad));
    % #5
    
    temp_glrlm = cell2mat(squeeze(struct2cell(features_glrlm)))';
    features_glrlm_vec = temp_glrlm(:);
    % #44
    
    features_ar_vec = cell2mat(struct2cell(features_ar));
    % #5
    
    features_haar_vec = cell2mat(struct2cell(features_haar));
    % #20
    
    %feat_numel = length(features_hist_vec)+length(features_grad_vec)+length(features_glrlm_vec)+length(features_ar_vec)+length(features_haar_vec)+length(features_hog_vec) ;   % #92
    % feat_numel = 92;
    FEAT_vector = vertcat(features_hist_vec, features_grad_vec, features_glrlm_vec, features_ar_vec, features_haar_vec, features_hog_vec );
