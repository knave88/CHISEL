function out = p7_refine (myI, I_in_bw, options)

try
    % identify objects
    bw_labeled_test = bwlabel(~ imfill(imclearborder(I_in_bw), 'holes'));
    %bw_labeled = bwlabel(~ imfill(I_in_bw, 'holes'));
    
    if max(max( bw_labeled_test )) == 1 && ~( sum(bw_labeled_test(:)) == size(bw_labeled_test,1)*size(bw_labeled_test,2) )
        bw_labeled = bwlabel(I_in_bw);
        bw_label_flag = false; %normal
    else
        bw_labeled = bwlabel(~I_in_bw);
        bw_label_flag = true; %inverted
    end
    
    if max(max( bw_labeled )) == 0
        out=[];
        return
    end
catch ME
    out=[];
    return
end

% I = lr_import_oryginal_file (file_name);
% myI = lr_choose_layer (I, options.segmentation.layer);
% if isempty(myI)
%     I_out=[];
%     return;
% end

% count objects
obj_num = max(max( bw_labeled ));

my_obj_found  = regionprops(bw_labeled, 'Centroid', 'Area', 'Perimeter','PixelList','Solidity', 'BoundingBox', 'Eccentricity');

I_out_bw = zeros(size(I_in_bw));


s = fun_classify_clasteroid (my_obj_found); % #TEMP


for k = 1 : length(my_obj_found)
    try
        
    current_bb = my_obj_found(k).BoundingBox;
    
    [current_img, myBB1] = extract_bb(myI, current_bb, options.refine.expand);
    [current_mask, myBB2] =  extract_bb(I_in_bw, current_bb, 0);
     

    current_out_final = process_boundingBox2 (current_img, current_mask, options);
    %current_out_final = process_boundingBox_newWay (current_img, current_mask, options);
    
    current_out_final = logical(current_out_final);
    
    [m_out n_out] = size(current_out_final);
    cut_out_final = current_out_final(1+options.refine.expand : m_out-options.refine.expand, 1+options.refine.expand : n_out-options.refine.expand);
    
    
    
    out_bb = expand_bb(current_bb, 0, size(I_in_bw));
    cut_out_final = imresize(cut_out_final, [out_bb(4)-out_bb(2)+1, out_bb(3)-out_bb(1)+1]); % #TODO resize poniewaz bounding box zaokraglamy i 1 piksel czasem zostaje
    I_out_bw( out_bb(2) : out_bb(4), out_bb(1) : out_bb(3) ) = cut_out_final; % #TODO wklejanie w obraz wynikowy na podstawie pikseli a nie boundingbox
    
    
    catch ME
        ME.message
        continue
    end
    
end


if options.refine.show_out
    figure; imagesc(I_in_bw); title('input');
    figure; imagesc(I_out_bw); title(['out = refined expand: ', num2str(options.refine.expand)]);
end

%--------------------------------------------------------------------------
% save results
if strcmpi (options.refine.cluster.when, 'none')
    options.refine.cluster.method = [];
end

% if options.refine.save
%     [pathstr,fname,fext] = fileparts(file_name) ;
%     if options.refine.expand > 0
%         new_file_name = [fname,'__refine',num2str(options.refine.refine_method),'_',num2str(options.refine.expand),fext]; %,options.refine.cluster.when,'_',
%         if ~isempty(options.refine.cluster.method)
%             new_file_name = [fname,'__refine',num2str(options.refine.refine_method),'_',num2str(options.refine.expand),'_',options.refine.cluster.when,'_',options.refine.cluster.method,fext];
%         end
%             
%     else
%         new_file_name = [fname,'__refine',num2str(options.refine.refine_method), fext];
%         if ~isempty(options.refine.cluster.method)
%             new_file_name = [fname,'__refine',num2str(options.refine.refine_method),'_',options.refine.cluster.when,'_',options.refine.cluster.method,fext];
%         end
%     end
%     imwrite(I_out_bw,new_file_name);
% end


% #TEMP
%out_postprocessing = lr_post7 (new_file_name, options.postprocessing);
% end #TEMP

out = I_out_bw;

%----------------------------------------------
%----------------------------------------------
%----------------------------------------------


function current_mask_out = process_boundingBox2 (current_img, current_mask, options)

current_mask_filled = imfill( padarray(current_mask,[options.refine.expand options.refine.expand]), 'holes');

%current_mask_filled_closed = imclose(current_mask_filled,strel('disk',2));
%current_mask_filled_areaopen = bwareaopen(current_mask_filled_closed,10,4);
current_mask_filled_areaopen = current_mask_filled;

if strcmpi(options.refine.cluster.when, 'before')
    try
        current_mask_filled_areaopen = refine_boundary_multi (current_img, current_mask_filled_areaopen, options.refine);
    catch
        current_mask_filled_areaopen = current_mask;
    end
end



s1  = regionprops(logical(current_mask_filled_areaopen), 'PixelList','PixelIdxList', 'Area', 'Perimeter','Eccentricity');

temp_out = zeros(size(current_mask_filled_areaopen));
temp_img = zeros(size(current_mask_filled_areaopen));
for k = 1:length(s1)
    temp_img = zeros(size(current_mask_filled_areaopen));
    temp_img(s1(k).PixelIdxList) = 1;
    
    
    recurrent_idx = 0;
    [temp_img, recurrent_idx] = fun_boundryBasedSplit2 (temp_img, options.refine.cluster, recurrent_idx, current_img);
    
    
    % split_testing
%     s_temp = fun_classify_clasteroid (s1);
%     if s_temp(k).clasteroid ~= 0 
%         split_testing(temp_img, options.refine.cluster, current_img, 0);
%     end
    %end split testing
    
    temp_out(logical(temp_img)) = 1;
    
    
end

%figure(3);imagesc(temp_out);
current_mask_afterSplit = temp_out;

%refine_testing(current_img, current_mask_afterSplit, options.refine, 0, current_mask);

if strcmpi(options.refine.cluster.when, 'after')
    %refine_testing(current_img, current_mask_afterSplit, options.refine, 0, current_mask);
    try
        current_mask_afterRefine = refine_boundary_multi (current_img, current_mask_afterSplit, options.refine);
    catch
        current_mask_afterRefine = temp_img;
    end
    current_mask_out = current_mask_afterRefine;
    
else
    current_mask_out = current_mask_afterSplit;
end




function out = expand_bb(boundingBox, expand, imgSize)
if expand >= 0
    bb1 = floor(boundingBox(1)-expand);
    if bb1<1
        bb1 = 1;
    end
    
    bb2 = floor(boundingBox(2)-expand); 
    if bb2 < 1
        bb2 = 1;
    end
    
    bb3 = ceil(boundingBox(1)+boundingBox(3)+expand);
    if bb3 > imgSize(2)
        bb3 = imgSize(2);
    end
    
    bb4 = ceil(boundingBox(2)+boundingBox(4)+expand);
    if bb4 > imgSize(1)
        bb4 = imgSize(1);
    end
    
    out = [bb1, bb2, bb3, bb4];
else
    out = boundingBox;
end
%out1 = floor(boundingBox(2)):ceil(boundingBox(2)+boundingBox(4));
%out2 = floor(boundingBox(1)):ceil(boundingBox(1)+boundingBox(3));


function [out_img, current_bb] = extract_bb(img, boundingBox, expand)
imgSize = size(img);

if expand >= 0
    bb1 = my_fix(boundingBox(1)-expand);
    bb2 = my_fix(boundingBox(2)-expand); 
    bb3 = ceil(boundingBox(1)+boundingBox(3)+expand);
    bb4 = ceil(boundingBox(2)+boundingBox(4)+expand);

    current_bb = [bb1, bb2, bb3, bb4];
    
    if bb1<1 || bb2 < 1 || bb3 > imgSize(2) || bb4 > imgSize(1)
        
        pad_size_pre = [0 0];
        pad_size_post = [0 0];
        
        if bb1<1
            new_bb1 = 1;
            %pad_size = [0 abs(bb1)];
            pad_size_pre(2) = abs(bb1);
            pad_dir = 'pre';
        else
            new_bb1 = bb1;
        end
        
        if bb2<1
            new_bb2 = 1;
            %pad_size = [abs(bb2) 0];
            pad_size_pre(1) = abs(bb2);
            pad_dir = 'pre';
        else
            new_bb2 = bb2;
        end
        
        if bb3 > imgSize(2)
            new_bb3 = imgSize(2);
            %pad_size = [0 abs(imgSize(1) - bb3)];
            pad_size_post(2) = abs(imgSize(2) - bb3);
            pad_dir = 'post';
        else
            new_bb3 = bb3;
        end
        
        if bb4 > imgSize(1)
            new_bb4 = imgSize(1);
            %pad_size = [abs(imgSize(2) - bb4) 0];
            pad_size_post(1) = abs(imgSize(1) - bb4);
            pad_dir = 'post';
        else
            new_bb4 = bb4;
        end
        
        current_bb = [new_bb1, new_bb2, new_bb3, new_bb4];
        temp_img = img( current_bb(2) : current_bb(4), current_bb(1) : current_bb(3) );
        
        %pad_val = 0;
        pad_val = 'symmetric';
        
        if bb1<1 || bb2<1
            pad_dir = 'pre';
            temp_img = padarray(temp_img, (pad_size_pre), pad_val, pad_dir);
        end
        if bb3 > imgSize(1) || bb4 > imgSize(2)
            pad_dir = 'post';
            temp_img = padarray(temp_img, (pad_size_post), pad_val, pad_dir);
        end
        out_img = temp_img;
        
    else
        out_img = img( current_bb(2) : current_bb(4), current_bb(1) : current_bb(3) );
    end
    
else
    out_img = [];
end


function output = my_fix (input)
if input>=0
    output = ceil(input);
else
    output = floor(input);
end
